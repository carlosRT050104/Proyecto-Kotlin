package com.example.apptiendita.servicios

data class LoginResponse(val success: Boolean, val message: String?)
