package com.example.apptiendita

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.example.apptiendita.adaptadores.*
import com.example.apptiendita.clases.*
import com.example.apptiendita.remoto.ApiUtil
import com.example.apptiendita.servicios.*
import com.example.apptiendita.utilidad.Util
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Fragmento_Detalle_Venta :  Fragment()  {
    //definiendo controles

    private lateinit var txtCantidadDetalleV: EditText
    private lateinit var txtPrecioDVenta: EditText
    private lateinit var cboCatVenta: Spinner
    private lateinit var cboCatPro: Spinner
    private lateinit var codDetalleVenta: TextView
    private lateinit var chkEstDetalleVenta: CheckBox


    private lateinit var lstTipoCancDetalleVen: ListView
    private lateinit var btnRegistrarDetalleven: Button
    private lateinit var btnActualizarDetalleven: Button
    private lateinit var btnEliminarDetalleven: Button

    private var dialogo: AlertDialog.Builder?=null

    //creamos un objeto de la clase Categoria
    val objectoventa= Venta()
    val objetoProducto= Producto()
    val objetoDetalleVenta=DetalleVenta()

    //declaramos el servicio
    private var ventaservice: VentaService?=null
    private var productoService: ProductoService?=null
    private var detalleservice: DetalleVentaService?=null

    //creamos un arraylist de Categoria
    private var registrodeventa:List<Venta>?=null
    private var registrodeproducto:List<Producto>?=null
    private var registrodedetalle:List<DetalleVenta>?=null

    //creamos un obejto de la clase utilidad
    var objutilidad= Util()

    private var ft: FragmentTransaction?=null

    //declaramos variables
    var cod=0
    var cant=""
    var precio=""
    var est=false

    var fila=-1
    var indice=-1

    var codve=0L
    var codpro=0L

    var pos=-1
    var posxd=1
    var nomcat=""
    var nomcatxd=""

    var nomprodxd=""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val raiz=inflater.inflate(R.layout.activity_fragmento_detalle_venta, container, false)

        //creacion de control
        txtCantidadDetalleV=raiz.findViewById(R.id.txtCantidadDetalleV)
        txtPrecioDVenta=raiz.findViewById(R.id.txtPrecioDVenta)
        cboCatVenta=raiz.findViewById(R.id.cboCatVenta)
        cboCatPro=raiz.findViewById(R.id.cboCatPro)
        codDetalleVenta=raiz.findViewById(R.id.codDetalleVenta)
        chkEstDetalleVenta=raiz.findViewById(R.id.chkEstDetalleVenta)

        lstTipoCancDetalleVen=raiz.findViewById(R.id. lstTipoCancDetalleVen)


        btnRegistrarDetalleven=raiz.findViewById(R.id.btnRegistrarDetalleven)
        btnActualizarDetalleven=raiz.findViewById(R.id.btnActualizarDetalleven)
        btnEliminarDetalleven=raiz.findViewById(R.id.btnEliminarDetalleven)


        //creamos el arraylist de Categoria
        registrodeventa=ArrayList()
        registrodeproducto=ArrayList()
        registrodedetalle=ArrayList()

        //implementamos el servicio
        ventaservice= ApiUtil.tipoCanchaService_Venta
        productoService= ApiUtil.tipoCanchaService
        detalleservice= ApiUtil.tipoCanchaService_DetalleVenta

        //llamamos ala funcion para mostrar los datos del combo
        MostrarComboProducto(raiz.context)
        MostrarComboVenta(raiz.context)

        //llamamos al metodo para mostrar los producto
        MostrarDetalleVenta(raiz.context)




        //generamos los eventos
        btnRegistrarDetalleven.setOnClickListener {
            if(txtCantidadDetalleV.getText().toString()==""){
                objutilidad.MensajeToast(raiz.context,"Ingrese la Cantidad")
                txtCantidadDetalleV.requestFocus()
            }else if(cboCatVenta.selectedItemPosition==-1){
                objutilidad.MensajeToast(raiz.context,"Seleccione la Fecha de la Venta")
                cboCatVenta.requestFocus()
            }else if(cboCatPro.selectedItemPosition==-1){
                objutilidad.MensajeToast(raiz.context,"Seleccione el Producto")
                cboCatPro.requestFocus()
            }else if(txtPrecioDVenta.getText().toString()==""){
                objutilidad.MensajeToast(raiz.context,"Ingrese el  Precio")
                txtPrecioDVenta.requestFocus()

            }else{
                //capturando valores
                cant=txtCantidadDetalleV.getText().toString()
                precio=txtPrecioDVenta.getText().toString()
                pos=cboCatVenta.selectedItemPosition
                posxd=cboCatPro.selectedItemPosition

                codve= (registrodeventa as ArrayList<Venta>).get(pos).idventa.toLong()
                nomcat= (registrodeventa as ArrayList<Venta>).get(pos).fecha.toString()

                codpro= (registrodeproducto as ArrayList<Producto>).get(pos).productoid.toLong()
                nomcatxd= (registrodeproducto as ArrayList<Producto>).get(pos).nombre.toString()


                est=if(chkEstDetalleVenta.isChecked){
                    true
                }else{
                    false
                }

                //enviamos los valores a la clase
                objetoDetalleVenta.cantidad=cant
                objetoDetalleVenta.precioventa=precio

                objetoProducto.productoid= codpro.toInt()
                objectoventa.idventa=codve.toInt()

                objetoDetalleVenta.Producto=objetoProducto
                objetoDetalleVenta.Venta=objectoventa

                objetoDetalleVenta.estado=est

                RegistrarProductoFetalleVen(raiz.context,objetoDetalleVenta)
                val fproducto=Fragmento_Detalle_Venta()
                DialogoCRUD(raiz.context,fproducto,"Registro de Detalle Venta","Se registro de Detalle Venta correctamente")



            }
        }
        lstTipoCancDetalleVen.setOnItemClickListener { parent, view, position, idventa ->
            fila = position
            codDetalleVenta.setText((registrodedetalle as ArrayList<DetalleVenta>)[fila].iddetallev.toString())
            txtCantidadDetalleV.setText((registrodedetalle as ArrayList<DetalleVenta>)[fila].cantidad)
            txtPrecioDVenta .setText((registrodedetalle as ArrayList<DetalleVenta>)[fila].precioventa)

            for(i in (registrodeventa as ArrayList<Venta>).indices){
                if((registrodeventa as ArrayList<Venta>).get(i).fecha== (registrodedetalle as ArrayList<DetalleVenta>).get(fila).Venta?.fecha){
                    indice=i
                }
            }
            cboCatVenta.setSelection(indice)

            for(i in (registrodeproducto as ArrayList<Producto>).indices){
                if((registrodeproducto as ArrayList<Producto>).get(i).nombre== (registrodedetalle as ArrayList<DetalleVenta>).get(fila).Producto?.nombre.toString()){
                    indice=i
                }
            }
            cboCatPro.setSelection(indice)

            if((registrodedetalle as ArrayList<DetalleVenta>)[fila].estado){
                chkEstDetalleVenta.setChecked(true)
            } else{
                chkEstDetalleVenta.setChecked(false)
            }
        }
        btnActualizarDetalleven.setOnClickListener {
            if(fila>=0){
                cod=Integer.parseInt(codDetalleVenta.getText().toString())
                cant=txtCantidadDetalleV.getText().toString()
                precio=txtPrecioDVenta.getText().toString()
                pos=cboCatVenta.selectedItemPosition
                posxd=cboCatPro.selectedItemPosition

                codve= (registrodeventa as ArrayList<Venta>).get(pos).idventa.toLong()
                nomcat= (registrodeventa as ArrayList<Venta>).get(pos).fecha.toString()

                codpro= (registrodeproducto as ArrayList<Producto>).get(pos).productoid.toLong()
                nomcatxd= (registrodeproducto as ArrayList<Producto>).get(pos).nombre.toString()


                est=if(chkEstDetalleVenta.isChecked){
                    true
                }else{
                    false
                }

                //enviamos los valores a la clase
                objetoDetalleVenta.cantidad=cant
                objetoDetalleVenta.precioventa=precio

                objetoProducto.productoid= codpro.toInt()
                objectoventa.idventa=codve.toInt()

                objetoDetalleVenta.Producto=objetoProducto
                objetoDetalleVenta.Venta=objectoventa

                objetoDetalleVenta.estado=est

                ActualizarTipoCanchaDetalleVen(raiz.context,objetoDetalleVenta,cod)
                val fproducto=FragmentoProducto()
                DialogoCRUD(raiz.context,fproducto,"Actualizacion de Detalle de Venta","Se actualizo el Detalle Venta correctamente")

            }else{
                objutilidad.MensajeToast(raiz.context,"Seleccione un elemento de la lista")
                lstTipoCancDetalleVen.requestFocus()
            }
        }
        btnEliminarDetalleven.setOnClickListener {
            if(fila>=0){
                cod= Integer.parseInt(codDetalleVenta.getText().toString())
                cant=txtCantidadDetalleV.getText().toString()
                precio=txtPrecioDVenta.getText().toString()

                pos=cboCatVenta.selectedItemPosition
                codve= (registrodeventa as ArrayList<Venta>).get(pos).idventa.toLong()
                nomcat= (registrodeventa as ArrayList<Venta>).get(pos).fecha.toString()

                posxd=cboCatPro.selectedItemPosition
                codpro= (registrodeproducto as ArrayList<Producto>).get(pos).productoid.toLong()
                nomprodxd= (registrodeproducto as ArrayList<Producto>).get(pos).nombre.toString()


                est=if(chkEstDetalleVenta.isChecked){
                    true
                }else{
                    false
                }

                //enviamos los valores a la clase
                objetoDetalleVenta.iddetallev= cod.toInt()
                objetoDetalleVenta.cantidad=cant
                objetoDetalleVenta.precioventa=precio

                objectoventa.idventa= codve.toInt()
                objetoDetalleVenta.Venta=objectoventa

                objetoProducto.productoid= codpro.toInt()
                objetoDetalleVenta.Producto=objetoProducto


                objetoDetalleVenta.estado=est

                ActualizarTipoCanchaDetalleVen(raiz.context,objetoDetalleVenta,cod)
                val fproducto=FragmentoProducto()
                DialogoCRUD(raiz.context,fproducto,"Actualizacion de Detalle de Venta","Se actualizo el Detalle de Venta correctamente")

            }else{
                objutilidad.MensajeToast(raiz.context,"Seleccione un elemento de la lista")
                lstTipoCancDetalleVen.requestFocus()
            }
        }

        btnEliminarDetalleven.setOnClickListener {

            if (fila >= 0){

                cod = codDetalleVenta.getText().toString().toInt()

                objetoDetalleVenta.iddetallev = cod

                EliminarTipoCancha(context, cod)
                val ftipocancha = FragmentoProducto()
                DialogoCRUD(raiz.context,ftipocancha,"Eliminar Detalle de Venta","Se Eliminino  el  Detalle de Venta correctamente")
            }
        }

        return raiz
    }

    //crear una funcion para que el combo cargue
    fun MostrarComboProducto(context: Context?){
        val call= productoService!!.MostrarTipoCanchaPersonalidaza()
        call!!.enqueue(object : Callback<List<Producto>?> {
            override fun onResponse(
                call: Call<List<Producto>?>,
                response: Response<List<Producto>?>
            ) {
                if(response.isSuccessful){
                    registrodeproducto=response.body()
                    cboCatPro.adapter= AdaptadorComboPro(context,registrodeproducto)
                }
            }

            override fun onFailure(call: Call<List<Producto>?>, t: Throwable) {
                Log.e("Error: ", t.message!!)
            }


        })
    }



    //crear una funcion para que el combo cargue
    fun MostrarComboVenta(context: Context?){
        val call= ventaservice!!.MostrarTipoCanchaPersonalidaza_Venta()
        call!!.enqueue(object : Callback<List<Venta>?> {
            override fun onResponse(
                call: Call<List<Venta>?>,
                response: Response<List<Venta>?>
            ) {
                if(response.isSuccessful){
                    registrodeventa=response.body()
                    cboCatVenta.adapter= AdaptadorComboVenta(context,registrodeventa)
                }
            }

            override fun onFailure(call: Call<List<Venta>?>, t: Throwable) {
                Log.e("Error: ", t.message!!)
            }

        })
    }



    //creamos la funcion para mostrar productos
    fun MostrarDetalleVenta(context: Context?){
        val call= detalleservice!!.MostrarTipoCanchaPersonalidaza_DetalleVenta()
        call!!.enqueue(object :Callback<List<DetalleVenta>?>{
            override fun onResponse(
                call: Call<List<DetalleVenta>?>,
                response: Response<List<DetalleVenta>?>
            ) {
                if(response.isSuccessful){
                    registrodedetalle=response.body()
                    lstTipoCancDetalleVen.adapter=AdaptadorDetalleVenta(context,registrodedetalle)
                }
            }

            override fun onFailure(call: Call<List<DetalleVenta>?>, t: Throwable) {
                Log.e("Error: ", t.message!!)
            }
        })
    }




    fun RegistrarProductoFetalleVen(context: Context?, tc:DetalleVenta?) {
        val call= detalleservice!!.RegistrarTipoCancha_DetalleVenta(tc)
        call!!.enqueue(object : Callback<List<DetalleVenta>> {
            override fun onResponse(
                call: Call<List<DetalleVenta>>,
                response: Response<List<DetalleVenta>>
            ) {
                if (response.isSuccessful){
                    Log.e("mensaje", "Se registro el detalle Venta")

                }
            }

            override fun onFailure(call: Call<List<DetalleVenta>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }


    fun ActualizarTipoCanchaDetalleVen(context: Context?, tc:DetalleVenta?, iddetallev: Int) {

        val call=detalleservice!!.ActualizarTipoCancha_DetalleVenta(iddetallev, tc)
        call!!.enqueue(object : Callback<List<DetalleVenta>> {
            override fun onResponse(
                call: Call<List<DetalleVenta>>,
                response: Response<List<DetalleVenta>>
            ) {
                if (response.isSuccessful){
                    Log.e("mensaje", "Se actualizo el detalle de venta")

                }
            }

            override fun onFailure(call: Call<List<DetalleVenta>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }
    fun EliminarTipoCancha(context: Context?, iddetallev:Int) {

        val call=detalleservice!!.EliminarTipoCancha_DetalleVenta(iddetallev)
        call!!.enqueue(object : Callback<List<DetalleVenta>> {
            override fun onResponse(
                call: Call<List<DetalleVenta>>,
                response: Response<List<DetalleVenta>>
            ) {
                if (response.isSuccessful){
                    Log.e("mensaje", "Se elimino el Detalle de Venta")

                }
            }

            override fun onFailure(call: Call<List<DetalleVenta>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        }
        )
    }
    //creamos un procedimiento para Mostrar dialogos de CRUD
    fun DialogoCRUD(context: Context, fproducto:Fragment,titulo:String,mensaje:String){
        dialogo= AlertDialog.Builder(context)
        dialogo!!.setTitle(titulo)
        dialogo!!.setMessage(mensaje)
        dialogo!!.setCancelable(false)
        dialogo!!.setPositiveButton("Ok"){
                dialog,which->
            ft=fragmentManager?.beginTransaction()
            ft?.addToBackStack(null)
            ft?.commit()
        }
        dialogo!!.show()
    }


    }