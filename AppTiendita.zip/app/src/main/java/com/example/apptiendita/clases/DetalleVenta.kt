package com.example.apptiendita.clases
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
class DetalleVenta {
    @SerializedName("iddetallev")
    @Expose
    var iddetallev: Int = 0

    @SerializedName("idventa")
    @Expose
    var Venta: Venta? = null

    @SerializedName("idprod")
    @Expose
    var Producto: Producto? = null

    @SerializedName("cantidad")
    @Expose
    var cantidad: String? = null

    @SerializedName("precioventa")
    @Expose
    var precioventa: String? = null


    @SerializedName("estado")
    @Expose
    var estado: Boolean = false

    constructor(
        iddetallev: Int,
        Venta: Venta?,
        Producto: Producto?,
        cantidad: String?,
        precioventa: String?,
        estado: Boolean
    ) {
        this.iddetallev = iddetallev
        this.Venta = Venta
        this.Producto = Producto
        this.cantidad = cantidad
        this.precioventa = precioventa
        this.estado = estado
    }

    constructor(){}

}