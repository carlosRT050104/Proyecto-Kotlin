package com.example.apptiendita.adaptadores

import com.example.apptiendita.clases.Cliente
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.apptiendita.R
import com.example.apptiendita.clases.Empleado
import com.example.apptiendita.clases.Venta

class AdaptadorVenta (context: Context?, private val listaVena:List<Venta>?):
    BaseAdapter() {
    private val layoutInflater: LayoutInflater
    init {
        layoutInflater=LayoutInflater.from(context)

    }

    override fun getCount(): Int {
        return listaVena!!.size
    }

    override fun getItem(p0: Int): Any {
        return listaVena!![p0]
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var vista = p1
        if (vista == null){

            vista=layoutInflater.inflate(R.layout.elemento_lista_venta, p2, false)
            val objtipocancha_Ve = getItem(p0) as Venta

            val etid = vista!!.findViewById<TextView>(R.id.etidVenta)
            val edfecha = vista!!.findViewById<TextView>(R.id.edtFechaVenta)
            val edtcli =vista!!.findViewById<TextView>(R.id.edtIdClienteaVenta)
            val etest = vista!!.findViewById<TextView>(R.id.etestVenta)

            etid.text = ""+objtipocancha_Ve.idventa
            edfecha.text = ""+objtipocancha_Ve.fecha
            edtcli.text=""+ objtipocancha_Ve.Cliente!!.nomcli
            if (objtipocancha_Ve.estado==true){
                etest.text="Habilitado"
            }else{
                etest.text="Deshabilitado"
            }
        }
        return vista!!
    }

}