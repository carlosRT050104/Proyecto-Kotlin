package com.example.apptiendita.adaptadores
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.apptiendita.R
import com.example.apptiendita.clases.*
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto

class AdaptadorBuscarRol   (context: Context, private val rol: List<Rol>?) : BaseAdapter()
{
    private val inflater: LayoutInflater = LayoutInflater.from(context)


    override fun getCount(): Int {
        return rol?.size ?: 0
    }

    override fun getItem(position: Int): Any? {
        return rol?.get(position)
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }


    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var vista = p1
        var viewHolder: AdaptadorBuscarRol.ViewHolder

        if (vista == null) {
            vista = inflater.inflate(R.layout.elemento_lista_rol, p2, false)
            viewHolder = AdaptadorBuscarRol.ViewHolder(vista)
            vista.tag = viewHolder
        } else {
            viewHolder = vista.tag as AdaptadorBuscarRol.ViewHolder
        }

        val objtipocancha = getItem(p0) as Rol

        viewHolder.lstCodRol.text = ""+objtipocancha.id_Cargo
        viewHolder.lstNomRol.text = ""+objtipocancha.nombre

        if (objtipocancha.activo) {
            viewHolder.etest.text = "Habilitado"
        } else {
            viewHolder.etest.text = "Deshabilitado"
        }

        return vista!!
    }
    private class ViewHolder(vista: View) {
        val lstCodRol=vista!!.findViewById<TextView>(R.id.lstCodRol)
        val lstNomRol=vista!!.findViewById<TextView>(R.id.lstNomRol)
        val etest=vista!!.findViewById<TextView>(R.id.lstEstRol)
    }
}