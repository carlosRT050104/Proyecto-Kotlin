package com.example.apptiendita

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ListView
import android.widget.SearchView
import android.widget.Toast
import androidx.fragment.app.FragmentTransaction
import com.example.apptiendita.adaptadores.*
import com.example.apptiendita.clases.*
import com.example.apptiendita.remoto.ApiUtil
import com.example.apptiendita.servicios.ProductoService
import com.example.apptiendita.servicios.RolService
import com.example.apptiendita.servicios.UsuarioService
import com.example.apptiendita.utilidad.Util
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class FragmentoBuscarUsuario : Fragment() {
    private lateinit var txtBuscarCliRol: SearchView
    private lateinit var btnBuscarCliRol:  Button
    private lateinit var btnListarTodoRol:  Button
    private lateinit var lstTipoCancCliRol:  ListView

    private var tipoCanchaServiceProRol: UsuarioService?=null

    private var registrotipocanchPro:List<Usuario>?=null

    private val objutilidad= Util()

    var ft: FragmentTransaction?=null


    private var _binding:FragmentoBuscarUsuario?=null

    private val binding get() = _binding!!

    @SuppressLint("SetTextI18n", "MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val raiz= inflater.inflate(R.layout.fragment_fragmento_buscar_usuario, container, false)
        txtBuscarCliRol  = raiz.findViewById(R.id.txtBusCliUsuario) //nombre
        btnBuscarCliRol =raiz.findViewById(R.id.btnSelCliUsuario)
        btnListarTodoRol= raiz.findViewById(R.id.btnListarTodoClienteUsuario)
        val txtBuscarCliRol = raiz.findViewById<SearchView>(R.id.txtBusCliUsuario)
        txtBuscarCliRol.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    buscarClientesPorNombre(query)
                    txtBuscarCliRol.clearFocus()
                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })

        lstTipoCancCliRol =raiz.findViewById(R.id.lstCliProUsuario)


        tipoCanchaServiceProRol = ApiUtil.usuarioService
        MostrarUsuario(raiz.context)

        btnBuscarCliRol.setOnClickListener {
            val name = txtBuscarCliRol.query.toString()

            if (name.isNotEmpty()) {
                buscarClientesPorNombre(name)

            } else {
                Toast.makeText(context, "Ingrese un nombre para buscar", Toast.LENGTH_SHORT).show()
            }
        }
        // Agregar el botón para mostrar todos los clientes
        btnListarTodoRol.setOnClickListener {
            MostrarUsuario(raiz.context)
        }
        return raiz
    }

    fun MostrarUsuario(context: Context?){
        val call= tipoCanchaServiceProRol!!.MostrarUsuarioPersonalizado()
        call!!.enqueue(object : Callback<List<Usuario>?> {
            override fun onResponse(
                call: Call<List<Usuario>?>,
                response: Response<List<Usuario>?>
            ) {
                if(response.isSuccessful){
                    registrotipocanchPro=response.body()
                    lstTipoCancCliRol.adapter= AdaptadorUsuario(context,registrotipocanchPro)
                }
            }

            override fun onFailure(call: Call<List<Usuario>?>, t: Throwable) {
                Log.e("Error: ",t.message!!)
            }


        })
    }

    private fun buscarClientesPorNombre(username: String) {
        val call=tipoCanchaServiceProRol!!.buscarPorNombre(username)
        call!!.enqueue(object: Callback<List<Usuario>> {
            override fun onResponse(call: Call<List<Usuario>>, response: Response<List<Usuario>>) {
                val clientes = response.body()
                lstTipoCancCliRol.adapter = context?.let { AdaptadorBuscarUsuario(it, clientes) }
            }

            override fun onFailure(call: Call<List<Usuario>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }

}