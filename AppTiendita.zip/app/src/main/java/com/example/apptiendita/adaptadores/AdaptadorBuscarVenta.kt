package com.example.apptiendita.adaptadores

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.apptiendita.R
import com.example.apptiendita.clases.*

class AdaptadorBuscarVenta  (context: Context, private val Venta: List<Venta>?) : BaseAdapter()
{
    private val inflater: LayoutInflater = LayoutInflater.from(context)

    override fun getCount(): Int {
        return Venta?.size ?: 0
    }

    override fun getItem(position: Int): Any? {
        return Venta?.get(position)
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var vista = p1
        var viewHolder: AdaptadorBuscarVenta.ViewHolder

        if (vista == null) {
            vista = inflater.inflate(R.layout.elemento_lista_venta, p2, false)
            viewHolder = AdaptadorBuscarVenta.ViewHolder(vista)
            vista.tag = viewHolder
        } else {
            viewHolder = vista.tag as AdaptadorBuscarVenta.ViewHolder
        }

        val objtipocancha = getItem(p0) as Venta

        viewHolder.etid.text = ""+objtipocancha.idventa
        viewHolder.edfecha.text = ""+objtipocancha.fecha
        viewHolder.edtcli.text=""+ objtipocancha.Cliente!!.nomcli

        if (objtipocancha.estado) {
            viewHolder.etest.text = "Habilitado"
        } else {
            viewHolder.etest.text = "Deshabilitado"
        }

        return vista!!
    }

    private class ViewHolder(vista: View) {
        val etid = vista!!.findViewById<TextView>(R.id.etidVenta)
        val edfecha = vista!!.findViewById<TextView>(R.id.edtFechaVenta)
        val edtcli =vista!!.findViewById<TextView>(R.id.edtIdClienteaVenta)
        val etest = vista!!.findViewById<TextView>(R.id.etestVenta)

    }

}