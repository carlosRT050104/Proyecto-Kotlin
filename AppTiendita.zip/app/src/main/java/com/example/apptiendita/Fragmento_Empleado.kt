package com.example.apptiendita

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.example.apptiendita.adaptadores.*
import com.example.apptiendita.clases.*
import com.example.apptiendita.remoto.ApiUtil
import com.example.apptiendita.servicios.*
import com.example.apptiendita.utilidad.Util
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Fragmento_Empleado :  Fragment() {
    private lateinit var txtnombreEm: EditText
    private lateinit var txtDirecEm: EditText
    private lateinit var txtApeEm: EditText
    private lateinit var txtTelfeEm: EditText

    private lateinit var chkEstEm: CheckBox
    private lateinit var lblidtipoEm: TextView
    private lateinit var btnRegistrarEm: Button
    private lateinit var btnActualizarEm: Button
    private lateinit var btnEliminarEm: Button
    private lateinit var lstTipoCancEm: ListView
    private lateinit var cboRol: Spinner
    private lateinit var lstUsu: ListView

    //creamo un objeto de la clase categiroa
    private val objrol= Rol()
    private var dialogo: AlertDialog.Builder?=null

    private val objtipocanchaEm=Empleado()

    private var cod = 0
    private var codrol=0
    private var nomrol=""
    private var nomem=""
    private var ape=""
    private var direc=""
    private var telef=""
    private var estem = false
    private var fila=-1
    private var indice=-1
    private var pos=-1

    private var tipoCanchaServiceEm: EmpleadoService?=null

    private var registrotipocanchaEm:List<Empleado>?=null

    private val objutilidad= Util()
    //declaramos el servicio
    private var rolService: RolService?=null

    //creamos un arraylist de categoria
    private var registroRol:List<Rol>?=null
    var ft: FragmentTransaction?=null


    private var _binding:Fragmento_Empleado?=null

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val raiz= inflater.inflate(R.layout.activity_fragmento_empleado, container, false)
        cboRol=raiz.findViewById(R.id.cboRol)
        txtnombreEm = raiz.findViewById(R.id.txtnombreEm)
        txtDirecEm = raiz.findViewById(R.id.txtPrecioEm)
        txtApeEm = raiz.findViewById(R.id.txtDescEm)
        txtTelfeEm = raiz.findViewById(R.id.txtTefEm)
        chkEstEm = raiz.findViewById(R.id.chkEstEm)

        lblidtipoEm = raiz.findViewById(R.id.lblidtipoEm)
        btnRegistrarEm = raiz.findViewById(R.id.btnRegistrarEm)
        btnActualizarEm = raiz.findViewById(R.id.btnActualizarEm)
        btnEliminarEm = raiz.findViewById(R.id.btnEliminarEm)
        lstTipoCancEm =raiz.findViewById(R.id.lstTipoCancEm)

        registroRol=ArrayList()
        registrotipocanchaEm=ArrayList()
        rolService= ApiUtil.rolService
        tipoCanchaServiceEm = ApiUtil.tipoCanchaService_Em
        MostrarTipoCanchaEm(raiz.context)
        MostrarComboRol(raiz.context)
        btnRegistrarEm.setOnClickListener {
            if (txtnombreEm.getText().toString()==""){
                objutilidad.MensajeToast(context, "Ingrese nombre del Empleado")
                txtnombreEm.requestFocus()

            }else if(txtDirecEm.getText().toString()==""){
                objutilidad.MensajeToast(context, "Ingrese Direccion del Empleado")
                txtDirecEm.requestFocus()
            }else if(txtApeEm.getText().toString()==""){
                objutilidad.MensajeToast(context, "Ingrese Apellido del Empleado")
                txtApeEm.requestFocus()
            }else if(txtTelfeEm.getText().toString()==""){
                objutilidad.MensajeToast(context, "Ingrese Telefono del Empleado")
                txtTelfeEm.requestFocus()
            }else if(cboRol.selectedItemPosition==-1){
                objutilidad.MensajeToast(raiz.context,"Selecciona un rol")
                cboRol.requestFocus()
            }else{
                nomem = txtnombreEm.getText().toString()
                ape= txtDirecEm.getText().toString()
                direc= txtApeEm.getText().toString()
                telef= txtTelfeEm.getText().toString()
                pos=cboRol.selectedItemPosition
                codrol=(registroRol as ArrayList<Rol>).get(pos).id_Cargo
                nomrol= (registroRol as ArrayList<Rol>).get(pos).nombre.toString()
                estem=if(chkEstEm.isChecked){
                    true
                }else{
                    false
                }
                objtipocanchaEm.nomtrab = nomem
                objtipocanchaEm.apetrab = ape
                objtipocanchaEm.directrab= direc
                objtipocanchaEm.teftrab = telef

                objrol.id_Cargo=codrol
                objtipocanchaEm.rol=objrol

                objtipocanchaEm.estado = estem

                RegistrarTipoCanchaEm(context, objtipocanchaEm)

                objutilidad.Limpiar(raiz.findViewById<View>(R.id.frmtipoCanchaEm) as ViewGroup)

                val ftipocancha = Fragmento_Empleado()
                DialogoCRUD(raiz.context,ftipocancha,"Registro de Empleado","Se Registro  el Empleado correctamente")

            }
        }
        txtnombreEm = raiz.findViewById(R.id.txtnombreEm)
        txtDirecEm = raiz.findViewById(R.id.txtPrecioEm)
        txtApeEm = raiz.findViewById(R.id.txtDescEm)
        txtTelfeEm = raiz.findViewById(R.id.txtTefEm)
        chkEstEm = raiz.findViewById(R.id.chkEstEm)
        lstTipoCancEm.setOnItemClickListener(AdapterView.OnItemClickListener
        { parent, view, position, productoid ->
            fila = position
            lblidtipoEm.setText(""+(registrotipocanchaEm as ArrayList<Empleado>).get(fila).idtrab)
            txtnombreEm.setText(""+(registrotipocanchaEm as ArrayList<Empleado>).get(fila).nomtrab)
            txtDirecEm.setText(""+(registrotipocanchaEm as ArrayList<Empleado>).get(fila).apetrab)
            txtApeEm.setText(""+(registrotipocanchaEm as ArrayList<Empleado>).get(fila).directrab)

            txtTelfeEm.setText(""+(registrotipocanchaEm as ArrayList<Empleado>).get(fila).teftrab)
            for(x in (registroRol as ArrayList<Rol>).indices){
                if((registroRol as ArrayList<Rol>).get(x).nombre== (registrotipocanchaEm as ArrayList<Empleado>).get(fila).rol?.nombre){
                    indice=x
                }
            }
            cboRol.setSelection(indice)
            if((registrotipocanchaEm as ArrayList<Empleado>).get(fila).estado){
                chkEstEm.setChecked(true)
            }else{
                chkEstEm.setChecked(false)
            }
        })
        btnActualizarEm.setOnClickListener {
            if (fila>=0){
                cod = lblidtipoEm.getText().toString().toInt()
                nomem = txtnombreEm.getText().toString()
                ape= txtDirecEm.getText().toString()
                direc= txtApeEm.getText().toString()
                telef= txtTelfeEm.getText().toString()
                pos=cboRol.selectedItemPosition
                codrol=(registroRol as ArrayList<Rol>).get(pos).id_Cargo
                nomrol= (registroRol as ArrayList<Rol>).get(pos).nombre.toString()
                estem=if(chkEstEm.isChecked){
                    true
                }else{
                    false
                }
            }
            objtipocanchaEm.nomtrab = nomem
            objtipocanchaEm.apetrab = ape
            objtipocanchaEm.directrab= direc
            objtipocanchaEm.teftrab = telef
            objrol.id_Cargo=codrol
            objtipocanchaEm.rol=objrol
            objtipocanchaEm.estado = estem

            ActualizarTipoCanchaEm(context, objtipocanchaEm, cod)

            objutilidad.Limpiar(raiz.findViewById<View>(R.id.frmtipoCanchaEm) as ViewGroup)

            val ftipocancha = Fragmento_Empleado()
            DialogoCRUD(raiz.context,ftipocancha,"Actualizar Empleado","Se Actualizo  el Empleado correctamente")

        }


        btnEliminarEm.setOnClickListener {

            if (fila >= 0){

                cod = lblidtipoEm.getText().toString().toInt()

                objtipocanchaEm.idtrab = cod

                EliminarTipoCanchaEm(context, cod)

                objutilidad.Limpiar(raiz.findViewById<View>(R.id.frmtipoCanchaEm) as ViewGroup)

                val ftipocancha = Fragmento_Empleado()
                DialogoCRUD(raiz.context,ftipocancha,"Eliminar Empleado","Se Eliminino  el Empleado correctamente")
            }
        }
        return raiz
    }
    fun MostrarTipoCanchaEm(context: Context?) {
        val call=tipoCanchaServiceEm!!.MostrarTipoCanchaPersonalidaza_Emp()
        call!!.enqueue(object: Callback<List<Empleado>> {
            override fun onResponse(
                call: Call<List<Empleado>>,
                response: Response<List<Empleado>>
            ) {
                if (response.isSuccessful){
                    registrotipocanchaEm=response.body()
                    lstTipoCancEm.adapter= AdaptadorEmpleado(context, registrotipocanchaEm)
                }
            }

            override fun onFailure(call: Call<List<Empleado>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }
    fun MostrarComboRol(context: Context?){
        val call= rolService!!.MostrarRolPersonalizado()
        call!!.enqueue(object : Callback<List<Rol>?> {
            override fun onResponse(
                call: Call<List<Rol>?>,
                response: Response<List<Rol>?>
            ) {
                if(response.isSuccessful){
                    registroRol=response.body()
                    cboRol.adapter= AdaptadorComboRol(context,registroRol)
                }
            }

            override fun onFailure(call: Call<List<Rol>?>, t: Throwable) {
                Log.e("Error: ",t.message!!)
            }


        })
    }

    fun RegistrarTipoCanchaEm(context: Context?, tcx:Empleado?) {
        val call=tipoCanchaServiceEm!!.RegistrarTipoCancha_Emp(tcx)
        call!!.enqueue(object : Callback<List<Empleado>> {
            override fun onResponse(
                call: Call<List<Empleado>>,
                response: Response<List<Empleado>>
            ) {
                if (response.isSuccessful){
                    Log.e("mensaje", "Se registro el empleado")

                }
            }

            override fun onFailure(call: Call<List<Empleado>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })

    }

    fun ActualizarTipoCanchaEm(context: Context?, tcx:Empleado?, idtrab:Int) {

        val call=tipoCanchaServiceEm!!.ActualizarTipoCancha_Emp(idtrab, tcx)
        call!!.enqueue(object : Callback<List<Empleado>> {
            override fun onResponse(
                call: Call<List<Empleado>>,
                response: Response<List<Empleado>>
            ) {
                if (response.isSuccessful){
                    Log.e("mensaje", "Se actualizo el empleado")

                }
            }

            override fun onFailure(call: Call<List<Empleado>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })

    }

    fun EliminarTipoCanchaEm(context: Context?, idtrab:Int) {

        val call=tipoCanchaServiceEm!!.EliminarTipoCancha_Emp(idtrab)
        call!!.enqueue(object : Callback<List<Empleado>> {
            override fun onResponse(
                call: Call<List<Empleado>>,
                response: Response<List<Empleado>>
            ) {
                if (response.isSuccessful){
                    Log.e("mensaje", "Se elimino  el empleado")

                }
            }

            override fun onFailure(call: Call<List<Empleado>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })

    }
    //creamos un procedimiento para Mostrar dialogos de CRUD
    fun DialogoCRUD(context: Context, fproducto:Fragment,titulo:String,mensaje:String){
        dialogo= AlertDialog.Builder(context)
        dialogo!!.setTitle(titulo)
        dialogo!!.setMessage(mensaje)
        dialogo!!.setCancelable(false)
        dialogo!!.setPositiveButton("Ok"){
                dialog,which->
            ft=fragmentManager?.beginTransaction()
            ft?.addToBackStack(null)
            ft?.commit()
        }
        dialogo!!.show()
    }

}