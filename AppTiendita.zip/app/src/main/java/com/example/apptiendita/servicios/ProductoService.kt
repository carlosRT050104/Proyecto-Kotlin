package com.example.apptiendita.servicios

import com.example.apptiendita.clases.Empleado
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto
import retrofit2.Call
import retrofit2.http.*

interface ProductoService {


    @GET("Producto/custom")
    fun MostrarTipoCanchaPersonalidaza(): Call<List<Producto>>

    @POST("Producto")
    fun RegistrarTipoCancha(@Body dt:Producto?): Call<List<Producto>>

    @PUT("Producto/{id}")
    fun ActualizarTipoCancha(@Path("id") productoid:Int, @Body dt:Producto?): Call<List<Producto>>

    @DELETE("Producto/{id}")
    fun EliminarTipoCancha(@Path("id") productoid:Int): Call<List<Producto>>


    @GET("Producto")
    fun buscarPorNombre(@Query("nombre") nombre: String): Call<List<Producto>>

}