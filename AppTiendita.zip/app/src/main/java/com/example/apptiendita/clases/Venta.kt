package com.example.apptiendita.clases

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Venta {
    @SerializedName("idventa")
    @Expose
    var idventa: Int = 0

    @SerializedName("fecha")
    @Expose
    var fecha: String? = null


    @SerializedName("idcliente")
    @Expose
    var Cliente: Cliente? = null

    @SerializedName("estado")
    @Expose
    var estado: Boolean = false

    constructor(idventa: Int, fecha: String?, Cliente: Cliente?, estado: Boolean) {
        this.idventa = idventa
        this.fecha = fecha
        this.Cliente = Cliente
        this.estado = estado
    }

    constructor(){}

}