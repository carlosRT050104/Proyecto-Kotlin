package com.example.apptiendita

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.apptiendita.utilidad.Util
import com.example.apptiendita.clases.Usuario
import com.example.apptiendita.remoto.ApiUtil
import com.example.apptiendita.remoto.ApiUtil.usuarioService
import com.example.apptiendita.remoto.RetrofitClient
import com.example.apptiendita.servicios.LoginResponse
import com.example.apptiendita.servicios.UsuarioService
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.http.*
import com.google.gson.GsonBuilder
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
class ActividadIngreso : AppCompatActivity() {

    //creamos un objeto de clase util
    private val objutilidad= Util()
    //declaramos variables para el usuario y clave
    private var usu=""
    private var cla=""

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.actividad_ingreso)



        //creamos una constet
        val txtUsu=findViewById<EditText>(R.id.txtuso)
        val txtCla=findViewById<EditText>(R.id.txtclave)
        val btnIngresar=findViewById<Button>(R.id.btnIngresar)
        val btnRegistro=findViewById<Button>(R.id.btnRegistarrNuevo)
        val btnSalir=findViewById<Button>(R.id.btnSalir)
        var usuarioService: UsuarioService?=null

        //creamos una variable para el contexto
        val contexT=this

         var retrofit: Retrofit?=null

        btnIngresar.setOnClickListener {
            val usuario = txtUsu.text.toString()
            val contrasena = txtCla.text.toString()

            if (usuario.isBlank()) {
                Toast.makeText(this, "Ingrese el usuario", Toast.LENGTH_SHORT).show()
                txtUsu.requestFocus()
                return@setOnClickListener
            }

            if (contrasena.isBlank()) {
                Toast.makeText(this, "Ingrese la contraseña", Toast.LENGTH_SHORT).show()
                txtCla.requestFocus()
                return@setOnClickListener
            }
            val API_URL ="http://192.168.18.4:9950/api-cancha/"

            // Construir instancia de Retrofit
            val retrofit = Retrofit.Builder()
                .baseUrl(API_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            // Crear instancia del servicio
            val servicio = retrofit.create(UsuarioService::class.java)

            // Realizar petición al servidor
            val llamada = servicio.login(usuario, contrasena)

            llamada.enqueue(object : Callback<LoginResponse> {
                override fun onResponse(
                    call: Call<LoginResponse>,
                    response: Response<LoginResponse>
                ) {
                    if (response.isSuccessful) {
                        val loginResponse = response.body()

                        if (loginResponse?.success == true) {
                            Toast.makeText(
                                this@ActividadIngreso,
                                "Bienvenido al sistema",
                                Toast.LENGTH_SHORT
                            ).show()

                            // Navegar a otra actividad si el login es exitoso
                            val formulario = Intent(this@ActividadIngreso, SplashActivity::class.java)
                            startActivity(formulario)
                            finish()
                        } else {
                            Toast.makeText(
                                this@ActividadIngreso,
                                "Usuario o contraseña no válidos",
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                    } else {
                        Toast.makeText(
                            this@ActividadIngreso,
                            "Error en la respuesta del servidor",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                    Toast.makeText(
                        this@ActividadIngreso,
                        "Error en la petición al servidor",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }

        btnSalir.setOnClickListener {
            objutilidad.SalirSistema(this)
        }
        btnRegistro.setOnClickListener {
            val intent = Intent(this, activityRegistroUsuario::class.java)
            startActivity(intent)
        }
        }
    }