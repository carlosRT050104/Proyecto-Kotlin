package com.example.apptiendita.adaptadores

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.apptiendita.R
import com.example.apptiendita.clases.Cliente
import com.example.apptiendita.clases.Empleado

class AdaptadorComboCli (context: Context?, private val listacliente:List<Cliente>?):
    BaseAdapter() {

    private val layoutInflater: LayoutInflater
    init {
        layoutInflater=LayoutInflater.from(context)

    }

    override fun getCount(): Int {
        return listacliente!!.size
    }

    override fun getItem(p0: Int): Any {
        return listacliente!![p0]
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var vista=p1
        if(vista==null){
            vista=layoutInflater.inflate(R.layout.elemento_combo_cliente,p2,false)
            val objcategoria=getItem(p0) as Cliente
            //creamos los controles
            val txtNomCboCat=vista!!.findViewById<TextView>(R.id.txtNomCboCatCli)
            //agregamos valores a los contrales
            txtNomCboCat.text=""+objcategoria.nomcli


        }
        return vista!!
    }
}