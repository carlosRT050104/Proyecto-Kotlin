package com.example.apptiendita.servicios
import com.example.apptiendita.clases.Cliente
import com.example.apptiendita.clases.Empleado
import retrofit2.Call
import retrofit2.http.*
interface EmpleadoService {
    @GET("Empleado/custom")
    fun MostrarTipoCanchaPersonalidaza_Emp(): Call<List<Empleado>>

    @POST("Empleado")
    fun RegistrarTipoCancha_Emp(@Body dt: Empleado?): Call<List<Empleado>>

    @PUT("Empleado/{id}")
    fun ActualizarTipoCancha_Emp(@Path("id") idtrab:Int, @Body dt:Empleado?): Call<List<Empleado>>

    @DELETE("Empleado/{id}")
    fun EliminarTipoCancha_Emp(@Path("id") idtrab:Int): Call<List<Empleado>>

    @GET("Empleado")
    fun buscarPorNombre(@Query("nombre") nombre: String): Call<List<Empleado>>

}