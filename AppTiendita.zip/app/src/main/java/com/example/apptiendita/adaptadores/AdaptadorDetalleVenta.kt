package com.example.apptiendita.adaptadores

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.apptiendita.R
import com.example.apptiendita.clases.DetalleVenta
import com.example.apptiendita.clases.Venta

class AdaptadorDetalleVenta (context: Context?, private val listaDetalleVena:List<DetalleVenta>?):
    BaseAdapter() {

    private val layoutInflater: LayoutInflater
    init {
        layoutInflater= LayoutInflater.from(context)

    }

    override fun getCount(): Int {
        return listaDetalleVena!!.size
    }

    override fun getItem(p0: Int): Any {
        return listaDetalleVena!![p0]
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var vista = p1
        if (vista == null){

            vista=layoutInflater.inflate(R.layout.elemento_lista_detalle_venta, p2, false)
            val objtipocancha_Detalle = getItem(p0) as DetalleVenta

            val etid = vista!!.findViewById<TextView>(R.id.edIDetalleVenta)
            val edtnompro = vista!!.findViewById<TextView>(R.id.edtNombrProductoDetalle)
            val edtfecha =vista!!.findViewById<TextView>(R.id.edtFechaVentaListaDetalle)
            val edtCantidad = vista!!.findViewById<TextView>(R.id.edtCantidadDetalle)
            val edtprecio = vista!!.findViewById<TextView>(R.id.edtPrecioVentaDetalle)
            val etest = vista!!.findViewById<TextView>(R.id.etestDetalleVenta)

            etid.text = ""+objtipocancha_Detalle.iddetallev
            edtfecha.text=""+ objtipocancha_Detalle.Venta!!.fecha
            edtnompro.text=""+ objtipocancha_Detalle.Producto!!.nombre
            edtCantidad.text = ""+objtipocancha_Detalle.cantidad
            edtprecio.text=""+ objtipocancha_Detalle.precioventa
            if (objtipocancha_Detalle.estado==true){
                etest.text="Habilitado"
            }else{
                etest.text="Deshabilitado"
            }
        }
        return vista!!
    }


}