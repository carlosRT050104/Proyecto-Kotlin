package com.example.apptiendita.clases

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Rol {
    @SerializedName("id_Cargo")
    @Expose
    var id_Cargo:Int=0

    @SerializedName("nombre")
    @Expose
    var nombre:String?=null

    @SerializedName("activo")
    @Expose
    var activo:Boolean=false

    //constructor
    constructor(){}
    constructor(id_Cargo: Int, nombre: String?, activo: Boolean) {
        this.id_Cargo = id_Cargo
        this.nombre = nombre
        this.activo = activo
    }


}