package com.example.apptiendita.clases
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Cliente {
    @SerializedName("idcliente")
    @Expose
    var idcliente: Int = 0

    @SerializedName("nomcli")
    @Expose
    var nomcli: String? = null

    @SerializedName("apecli")
    @Expose
    var apecli: String? = null

    @SerializedName("tefcli")
    @Expose
    var tefcli: String? = null

    @SerializedName("dni")
    @Expose
    var dni: String? = null

    @SerializedName("direccion")
    @Expose
    var direccion: String? = null

    @SerializedName("estado")
    @Expose
    var estado: Boolean = false

    constructor(
        idcliente: Int,
        nomcli: String?,
        apecli: String?,
        tefcli: String?,
        dni: String?,
        direccion: String?,
        estado: Boolean
    ) {
        this.idcliente = idcliente
        this.nomcli = nomcli
        this.apecli = apecli
        this.tefcli = tefcli
        this.dni = dni
        this.direccion = direccion
        this.estado = estado
    }
    constructor(){}

}