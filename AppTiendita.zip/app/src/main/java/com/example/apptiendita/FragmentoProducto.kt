package com.example.apptiendita

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.example.apptiendita.adaptadores.AdaptadorProducto
import com.example.apptiendita.remoto.ApiUtil
import com.example.apptiendita.servicios.ProductoService
import com.example.apptiendita.utilidad.Util
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class FragmentoProducto : Fragment() {


    private lateinit var txtnombrePro: EditText
    private lateinit var txtDecPro: EditText
    private lateinit var txtPrecPro: EditText
    private lateinit var chkEst: CheckBox
    private lateinit var lblidtipo: TextView
    private var imageView: ImageView? = null

    private lateinit var btnRegistrar: Button
    private lateinit var btnActualizar: Button
    private lateinit var btnEliminar: Button
    private lateinit var lstTipoCanc: ListView

    private var dialogo: AlertDialog.Builder?=null

    private val objtipocancha=Producto()

    private var cod = 0
    private var fila =-1

    private var nom=""
    private var descrip=""
    private var precio=""
    private var est = false

    private var tipoCanchaService: ProductoService?=null

    private var registrotipocancha:List<Producto>?=null

    private val objutilidad= Util()

    var ft: FragmentTransaction?=null


    private var _binding:FragmentoProducto?=null

    private val binding get() = _binding!!



    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val raiz= inflater.inflate(R.layout.fragmento_producto, container, false)
        // Encuentra la vista del ImageView y establece su visibilidad en GONE
        imageView = raiz.findViewById(R.id.imageview)
        imageView?.visibility = View.GONE
        txtnombrePro = raiz.findViewById(R.id.txtnombrePro)
        txtDecPro = raiz.findViewById(R.id.txtDescrip)
        txtPrecPro = raiz.findViewById(R.id.txtPrecioPro)
        chkEst = raiz.findViewById(R.id.chkEst)

        lblidtipo = raiz.findViewById(R.id.lblidtipo)
        btnRegistrar = raiz.findViewById(R.id.btnRegistrar)
        btnActualizar = raiz.findViewById(R.id.btnActualizar)
        btnEliminar = raiz.findViewById(R.id.btnEliminar)
        lstTipoCanc =raiz.findViewById(R.id.lstTipoCanc)

        registrotipocancha=ArrayList()
        tipoCanchaService = ApiUtil.tipoCanchaService
        MostrarTipoCancha(raiz.context)

        btnRegistrar.setOnClickListener {
            if (txtnombrePro.getText().toString()==""){
                objutilidad.MensajeToast(context, "Ingrese nombre del Producto")
                txtnombrePro.requestFocus()

            }else if(txtDecPro.getText().toString()==""){
                objutilidad.MensajeToast(context, "Ingrese Descripcion del Producto")
                txtDecPro.requestFocus()
            }else if(txtPrecPro.getText().toString()==""){
                objutilidad.MensajeToast(context, "Ingrese Precio del Producto")
                txtPrecPro.requestFocus()
            }else{
                nom = txtnombrePro.getText().toString()
                descrip = txtDecPro.getText().toString()
                precio = txtPrecPro.getText().toString()
                est=if(chkEst.isChecked){
                    true
                }else{
                    false
                }
                objtipocancha.nombre = nom
                objtipocancha.descripcion = descrip
                objtipocancha.precio = precio
                objtipocancha.estado = est

                RegistrarTipoCancha(context, objtipocancha)

                objutilidad.Limpiar(raiz.findViewById<View>(R.id.frmTipoCancha) as ViewGroup)

                val ftipocancha = FragmentoProducto()
                DialogoCRUD(raiz.context,ftipocancha,"Registro de  Producto","Se Registro  el Producto correctamente")
            }
        }
        lstTipoCanc.setOnItemClickListener(AdapterView.OnItemClickListener
        { parent, view, position, productoid ->
            fila = position
            lblidtipo.setText(""+(registrotipocancha as ArrayList<Producto>).get(fila).productoid)
            txtnombrePro.setText(""+(registrotipocancha as ArrayList<Producto>).get(fila).nombre)
            txtDecPro.setText(""+(registrotipocancha as ArrayList<Producto>).get(fila).descripcion)
            txtPrecPro.setText(""+(registrotipocancha as ArrayList<Producto>).get(fila).precio)
            if((registrotipocancha as ArrayList<Producto>).get(fila).estado){
                chkEst.setChecked(true)
            }else{
                chkEst.setChecked(false)
            }
        })


        btnActualizar.setOnClickListener {
            if (fila>=0){
                cod = lblidtipo.getText().toString().toInt()
                nom = txtnombrePro.getText().toString()
                descrip = txtDecPro.getText().toString()
                precio = txtPrecPro.getText().toString()
                est=if(chkEst.isChecked){
                    true
                }else{
                    false
                }
            }
            objtipocancha.nombre = nom
            objtipocancha.descripcion = descrip
            objtipocancha.precio = precio
            objtipocancha.estado = est

            ActualizarTipoCancha(context, objtipocancha, cod)

            objutilidad.Limpiar(raiz.findViewById<View>(R.id.frmTipoCancha) as ViewGroup)

            val ftipocancha = FragmentoProducto()
            DialogoCRUD(raiz.context,ftipocancha,"Actualizar  Producto","Se Actualizo  el Producto correctamente")

        }


        btnEliminar.setOnClickListener {

            if (fila >= 0){

                cod = lblidtipo.getText().toString().toInt()

                objtipocancha.productoid = cod

                EliminarTipoCancha(context, cod)

                objutilidad.Limpiar(raiz.findViewById<View>(R.id.frmTipoCancha) as ViewGroup)

                val ftipocancha = FragmentoProducto()
              DialogoCRUD(raiz.context,ftipocancha,"Eliminar  Producto","Se Eliminino  el Producto correctamente")
        }
        }

        return raiz

    }


    fun MostrarTipoCancha(context: Context?) {
        val call=tipoCanchaService!!.MostrarTipoCanchaPersonalidaza()
        call!!.enqueue(object: Callback<List<Producto>> {
            override fun onResponse(
                call: Call<List<Producto>>,
                response: Response<List<Producto>>
            ) {
                if (response.isSuccessful){
                    registrotipocancha=response.body()
                    lstTipoCanc.adapter= AdaptadorProducto(context, registrotipocancha)
                }
            }

            override fun onFailure(call: Call<List<Producto>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }

    fun RegistrarTipoCancha(context: Context?, tc:Producto?) {

        val call=tipoCanchaService!!.RegistrarTipoCancha(tc)
        call!!.enqueue(object : Callback<List<Producto>> {
            override fun onResponse(
                call: Call<List<Producto>>,
                response: Response<List<Producto>>
            ) {
                if (response.isSuccessful){
                    Log.e("mensaje", "Se registro el producto")

                }
            }

            override fun onFailure(call: Call<List<Producto>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })

    }

    fun ActualizarTipoCancha(context: Context?, tc:Producto?, productoid:Int) {

        val call=tipoCanchaService!!.ActualizarTipoCancha(productoid, tc)
        call!!.enqueue(object : Callback<List<Producto>> {
            override fun onResponse(
                call: Call<List<Producto>>,
                response: Response<List<Producto>>
            ) {
                if (response.isSuccessful){
                    Log.e("mensaje", "Se actualizo el producto ")

                }
            }

            override fun onFailure(call: Call<List<Producto>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })

    }

    fun EliminarTipoCancha(context: Context?, productoid:Int) {

        val call=tipoCanchaService!!.EliminarTipoCancha(productoid)
        call!!.enqueue(object : Callback<List<Producto>> {
            override fun onResponse(
                call: Call<List<Producto>>,
                response: Response<List<Producto>>
            ) {
                if (response.isSuccessful){
                    Log.e("mensaje", "Se elimino el producto")

                }
            }

            override fun onFailure(call: Call<List<Producto>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })

    }
    //creamos un procedimiento para Mostrar dialogos de CRUD
    fun DialogoCRUD(context: Context, fproducto:Fragment,titulo:String,mensaje:String){
        dialogo= AlertDialog.Builder(context)
        dialogo!!.setTitle(titulo)
        dialogo!!.setMessage(mensaje)
        dialogo!!.setCancelable(false)
        dialogo!!.setPositiveButton("Ok"){
                dialog,which->
            ft=fragmentManager?.beginTransaction()
            ft?.addToBackStack(null)
            ft?.commit()
        }
        dialogo!!.show()
    }
}