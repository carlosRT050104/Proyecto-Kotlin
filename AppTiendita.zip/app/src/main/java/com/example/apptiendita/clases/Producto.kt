package com.example.proyecto_movil_crud_mysql_23_52.Clases

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Producto {
    @SerializedName("productoid")
    @Expose
    var productoid: Int = 0

    @SerializedName("nombre")
    @Expose
    var nombre: String? = null

    @SerializedName("descripcion")
    @Expose
    var descripcion: String? = null


    @SerializedName("precio")
    @Expose
    var precio: String? = null

    @SerializedName("estado")
    @Expose
    var estado: Boolean = false

    constructor(
        productoid: Int,
        nombre: String?,
        descripcion: String?,
        precio: String?,
        estado: Boolean
    ) {
        this.productoid = productoid
        this.nombre = nombre
        this.descripcion = descripcion
        this.precio = precio
        this.estado = estado
    }
    constructor(){}

}
