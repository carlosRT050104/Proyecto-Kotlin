package com.example.apptiendita

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ListView
import android.widget.SearchView
import android.widget.Toast
import androidx.fragment.app.FragmentTransaction
import com.example.apptiendita.adaptadores.AdaptadorBuscarCliente
import com.example.apptiendita.adaptadores.AdaptadorBuscarEmpleado
import com.example.apptiendita.adaptadores.AdaptadorCliente
import com.example.apptiendita.clases.Cliente
import com.example.apptiendita.clases.Empleado
import com.example.apptiendita.remoto.ApiUtil
import com.example.apptiendita.servicios.ClienteService
import com.example.apptiendita.servicios.EmpleadoService
import com.example.apptiendita.utilidad.Util
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class FragmentoBuscarEmpleado : Fragment() {
    private lateinit var txtBusCliTra: SearchView
    private lateinit var btnSelCliTra: Button
    private lateinit var btnListarTodoClienteTrab: Button
    private lateinit var lstCliTra: ListView

    private var dialogo: AlertDialog.Builder?=null

    private val objtipocancha_Cli= Empleado()


    private var estem = false

    private var tipoCanchaServiceClienteTraba: EmpleadoService?=null

    private var registrotipocanchaCliente:List<Empleado>?=null

    private val objutilidad= Util()

    var ft: FragmentTransaction?=null


    private var _binding:FragmentoBuscarCliente?=null

    private val binding get() = _binding!!
    @SuppressLint("SetTextI18n")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val raiz= inflater.inflate(R.layout.fragment_fragmento_buscar_empleado, container, false)
        txtBusCliTra = raiz.findViewById(R.id.txtBusCliTra) //nombre
        btnSelCliTra=raiz.findViewById(R.id.btnSelCliTra)
        btnListarTodoClienteTrab=raiz.findViewById(R.id.btnListarTodoClienteTrab)
        val txtBusCliTra = raiz.findViewById<SearchView>(R.id.txtBusCliTra)
        txtBusCliTra.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    buscarClientesEmpleadoPorNombre(query)
                    txtBusCliTra.clearFocus()
                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })

        lstCliTra =raiz.findViewById(R.id.lstCliTra)


        tipoCanchaServiceClienteTraba= ApiUtil.tipoCanchaService_Em
        MostrarTipoCanchaClienteEmpleado(raiz.context)

        btnSelCliTra.setOnClickListener {
            val name = txtBusCliTra.query.toString()

            if (name.isNotEmpty()) {
                buscarClientesEmpleadoPorNombre(name)

            } else {
                Toast.makeText(context, "Ingrese un nombre para buscar", Toast.LENGTH_SHORT).show()
            }
        }
        // Agregar el botón para mostrar todos los clientes
        btnListarTodoClienteTrab.setOnClickListener {
            mostrarTodosLosClientesEmpleado()
        }
        return raiz
    }
    private fun buscarClientesEmpleadoPorNombre(nombre: String) {
        val call = tipoCanchaServiceClienteTraba!!.buscarPorNombre(nombre)
        call!!.enqueue(object : Callback<List<Empleado>> {
            override fun onResponse(call: Call<List<Empleado>>, response: Response<List<Empleado>>) {
                val empleado = response.body()
                lstCliTra.adapter = context?.let { AdaptadorBuscarEmpleado(it, empleado) }
            }

            override fun onFailure(call: Call<List<Empleado>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }


    private fun mostrarTodosLosClientesEmpleado() {
        val call = tipoCanchaServiceClienteTraba!!.MostrarTipoCanchaPersonalidaza_Emp()
        call!!.enqueue(object : Callback<List<Empleado>> {
            override fun onResponse(call: Call<List<Empleado>>, response: Response<List<Empleado>>) {
                val empleado = response.body()
                lstCliTra.adapter = context?.let { AdaptadorBuscarEmpleado(it, empleado) }

            }

            override fun onFailure(call: Call<List<Empleado>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }
    fun MostrarTipoCanchaClienteEmpleado(context: Context?) {
        val call = tipoCanchaServiceClienteTraba!!.MostrarTipoCanchaPersonalidaza_Emp()
        call!!.enqueue(object : Callback<List<Empleado>> {
            override fun onResponse(call: Call<List<Empleado>>, response: Response<List<Empleado>>) {
                val empleado = response.body()
                lstCliTra.adapter = context?.let { AdaptadorBuscarEmpleado(it, empleado) }

            }

            override fun onFailure(call: Call<List<Empleado>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }
    //creamos u
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


    }

    override fun onDestroyView() {
        super.onDestroyView()

    }
}