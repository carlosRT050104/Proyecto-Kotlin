package com.example.apptiendita.adaptadores

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.apptiendita.R
import com.example.apptiendita.clases.Cliente
import com.example.apptiendita.clases.Venta

class AdaptadorComboVenta (context: Context?, private val listaventa:List<Venta>?):
    BaseAdapter() {
    private val layoutInflater: LayoutInflater
    init {
        layoutInflater= LayoutInflater.from(context)

    }

    override fun getCount(): Int {
        return listaventa!!.size
    }

    override fun getItem(p0: Int): Any {
        return listaventa!![p0]
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var vista=p1
        if(vista==null){
            vista=layoutInflater.inflate(R.layout.elemento_combo_venta,p2,false)
            val objcategoriaVenta=getItem(p0) as Venta
            //creamos los controles
            val txtFechaboCatVenta=vista!!.findViewById<TextView>(R.id.txtFechaboCatVenta)
            //agregamos valores a los contrales
            txtFechaboCatVenta.text=""+objcategoriaVenta.fecha

        }
        return vista!!
    }


}