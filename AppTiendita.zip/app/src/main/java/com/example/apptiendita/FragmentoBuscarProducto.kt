package com.example.apptiendita

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.FragmentTransaction
import com.example.apptiendita.adaptadores.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.example.apptiendita.clases.*
import com.example.apptiendita.remoto.ApiUtil
import com.example.apptiendita.remoto.RetrofitClient
import com.example.apptiendita.servicios.*
import com.example.apptiendita.utilidad.Util
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto

class FragmentoBuscarProducto : Fragment() {
    private lateinit var txtBuscarCliPro: SearchView
    private lateinit var btnBuscarCliPro: Button
    private lateinit var btnListarTodoPro:Button
    private lateinit var lstTipoCancCliPro: ListView

    private var dialogo: AlertDialog.Builder?=null

    private val objtipocancha_Cli= Producto()


    private var estem = false

    private var tipoCanchaServicePro: ProductoService?=null

    private var registrotipocanchPro:List<Producto>?=null

    private val objutilidad= Util()

    var ft: FragmentTransaction?=null


    private var _binding:FragmentoBuscarProducto?=null

    private val binding get() = _binding!!

    @SuppressLint("SetTextI18n")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val raiz= inflater.inflate(R.layout.fragment_fragmento_buscar_producto, container, false)
        txtBuscarCliPro = raiz.findViewById(R.id.txtBusCliPro) //nombre
        btnBuscarCliPro=raiz.findViewById(R.id.btnSelCliPro)
        btnListarTodoPro=raiz.findViewById(R.id.btnListarTodoClientePro)
        val txtBuscarCliPro = raiz.findViewById<SearchView>(R.id.txtBusCliPro)
        txtBuscarCliPro.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    buscarClientesPorNombre(query)
                    txtBuscarCliPro.clearFocus()
                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })

        lstTipoCancCliPro =raiz.findViewById(R.id.lstCliPro)


        tipoCanchaServicePro = ApiUtil.tipoCanchaService
        MostrarTipoCanchaCliente(raiz.context)

        btnBuscarCliPro.setOnClickListener {
            val name = txtBuscarCliPro.query.toString()

            if (name.isNotEmpty()) {
                buscarClientesPorNombre(name)

            } else {
                Toast.makeText(context, "Ingrese un nombre para buscar", Toast.LENGTH_SHORT).show()
            }
        }
        // Agregar el botón para mostrar todos los clientes
        btnListarTodoPro.setOnClickListener {
            mostrarTodosLosClientes()
        }
        return raiz
    }

    private fun buscarClientesPorNombre(nombre: String) {
        val call=tipoCanchaServicePro!!.buscarPorNombre(nombre)
        call!!.enqueue(object: Callback<List<Producto>> {
            override fun onResponse(call: Call<List<Producto>>, response: Response<List<Producto>>) {
                val clientes = response.body()
                lstTipoCancCliPro.adapter = context?.let { AdaptadorBuscarProducto(it, clientes) }
            }

            override fun onFailure(call: Call<List<Producto>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }
    fun MostrarTipoCanchaCliente(context: Context?) {
        val call=tipoCanchaServicePro!!.MostrarTipoCanchaPersonalidaza()
        call!!.enqueue(object: Callback<List<Producto>> {
            override fun onResponse(call: Call<List<Producto>>, response: Response<List<Producto>>) {
                if (response.isSuccessful){
                    registrotipocanchPro=response.body()
                    lstTipoCancCliPro.adapter= AdaptadorProducto(context, registrotipocanchPro)
                }
            }

            override fun onFailure(call: Call<List<Producto>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }
    private fun mostrarTodosLosClientes() {
        val call = tipoCanchaServicePro!!.MostrarTipoCanchaPersonalidaza()
        call!!.enqueue(object : Callback<List<Producto>> {
            override fun onResponse(call: Call<List<Producto>>, response: Response<List<Producto>>) {
                val clientes = response.body()
                lstTipoCancCliPro.adapter = context?.let { AdaptadorBuscarProducto(it, clientes) }

            }

            override fun onFailure(call: Call<List<Producto>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


    }

    override fun onDestroyView() {
        super.onDestroyView()

    }
}