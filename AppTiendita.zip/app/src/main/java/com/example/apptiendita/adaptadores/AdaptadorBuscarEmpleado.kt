package com.example.apptiendita.adaptadores
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.apptiendita.R
import com.example.apptiendita.clases.Cliente
import com.example.apptiendita.clases.Empleado
import com.example.proyecto_movil_crud_mysql_23_52.Clases.*

class AdaptadorBuscarEmpleado (context: Context, private val Empleado: List<Empleado>?) : BaseAdapter() {
    private val inflater: LayoutInflater = LayoutInflater.from(context)

    override fun getCount(): Int {
        return Empleado?.size ?: 0
    }

    override fun getItem(position: Int): Any? {
        return Empleado?.get(position)
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var vista = p1
        var viewHolder: ViewHolder

        if (vista == null) {
            vista = inflater.inflate(R.layout.elemento_lista_empleado, p2, false)
            viewHolder = ViewHolder(vista)
            vista.tag = viewHolder
        } else {
            viewHolder = vista.tag as ViewHolder
        }

        val objtipocancha_Cli = getItem(p0) as Empleado

        viewHolder.etid.text = "" + objtipocancha_Cli.idtrab
        viewHolder.edtnom.text = objtipocancha_Cli.nomtrab
        viewHolder.edtApe.text = objtipocancha_Cli.apetrab
        viewHolder.edttelef.text = objtipocancha_Cli.teftrab
        viewHolder.edtdec.text = objtipocancha_Cli.directrab
        viewHolder.lstRolUsuario.text = objtipocancha_Cli.rol!!.nombre

        if (objtipocancha_Cli.estado) {
            viewHolder.etest.text = "Habilitado"
        } else {
            viewHolder.etest.text = "Deshabilitado"
        }

        return vista!!
    }

    private class ViewHolder(vista: View) {
        val etid = vista!!.findViewById<TextView>(R.id.etidem)
        val edtnom = vista!!.findViewById<TextView>(R.id.edtNombreEm)
        val edtApe= vista!!.findViewById<TextView>(R.id.edtApeEm)
        val edtdec= vista!!.findViewById<TextView>(R.id.edtDireccEm)
        val edttelef = vista!!.findViewById<TextView>(R.id.edtTelefEm)
        val etest = vista!!.findViewById<TextView>(R.id.etestEm)
        val lstRolUsuario=vista!!.findViewById<TextView>(R.id.lstRolUsuario)
    }


}