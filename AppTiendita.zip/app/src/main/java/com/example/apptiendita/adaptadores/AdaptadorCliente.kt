package com.example.apptiendita.adaptadores
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.apptiendita.R
import com.example.apptiendita.clases.Cliente
import com.example.apptiendita.clases.Empleado
import com.example.proyecto_movil_crud_mysql_23_52.Clases.*

class AdaptadorCliente  (context: Context?, private val listatipocancha_Cli:List<Cliente>?):BaseAdapter()
{
    private val layoutInflater: LayoutInflater

    init {
        layoutInflater= LayoutInflater.from(context)
    }

    override fun getCount(): Int {
        return listatipocancha_Cli!!.size
    }

    override fun getItem(p0: Int): Any {
        return listatipocancha_Cli!![p0]
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var vista = p1
        if (vista == null){

            vista=layoutInflater.inflate(R.layout.elemento_lista_cliente, p2, false)
            val objtipocancha_Cli = getItem(p0) as Cliente

            val etid = vista!!.findViewById<TextView>(R.id.etidcli)
            val edtnom = vista!!.findViewById<TextView>(R.id.edtNombrecli) //nombre
            val edtApe= vista!!.findViewById<TextView>(R.id.edtApeCli) // apellido
            val edttelef = vista!!.findViewById<TextView>(R.id.edtTelefCli) //telefono
            val edtdni= vista!!.findViewById<TextView>(R.id.edtDni) //dni
            val edtdec= vista!!.findViewById<TextView>(R.id.edtDirecCli) //direccion
            val etest = vista!!.findViewById<TextView>(R.id.etestCli)

            etid.text = ""+objtipocancha_Cli.idcliente
            edtnom.text = ""+objtipocancha_Cli.nomcli
            edtApe.text = ""+objtipocancha_Cli.apecli
            edttelef.text = ""+objtipocancha_Cli.tefcli
            edtdni.text = ""+objtipocancha_Cli.dni
            edtdec.text = ""+objtipocancha_Cli.direccion

            if (objtipocancha_Cli.estado==true){
                etest.text="Habilitado"
            }else{
                etest.text="Deshabilitado"
            }
        }
        return vista!!
    }

}