package com.example.apptiendita.clases
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Empleado {
    @SerializedName("idtrab")
    @Expose
    var idtrab: Int = 0

    @SerializedName("nomtrab")
    @Expose
    var nomtrab: String? = null

    @SerializedName("apetrab")
    @Expose
    var apetrab: String? = null

    @SerializedName("directrab")
    @Expose
    var directrab: String? = null


    @SerializedName("teftrab")
    @Expose
    var teftrab: String? = null

    @SerializedName("id_Cargo")
    @Expose
    var rol:Rol?=null

    @SerializedName("estado")
    @Expose
    var estado: Boolean = false


    constructor(){}
    constructor(
        idtrab: Int,
        nomtrab: String?,
        apetrab: String?,
        directrab: String?,
        teftrab: String?,
        rol: Rol?,
        estado: Boolean
    ) {
        this.idtrab = idtrab
        this.nomtrab = nomtrab
        this.apetrab = apetrab
        this.directrab = directrab
        this.teftrab = teftrab
        this.rol = rol
        this.estado = estado
    }
}