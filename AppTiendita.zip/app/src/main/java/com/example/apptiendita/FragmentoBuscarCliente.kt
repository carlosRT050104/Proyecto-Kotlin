package com.example.apptiendita

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.FragmentTransaction
import com.example.apptiendita.adaptadores.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.example.apptiendita.clases.*
import com.example.apptiendita.remoto.ApiUtil
import com.example.apptiendita.remoto.RetrofitClient
import com.example.apptiendita.servicios.*
import com.example.apptiendita.utilidad.Util



class FragmentoBuscarCliente : Fragment() {
    private lateinit var txtBuscarCli: SearchView
    private lateinit var btnBuscarCli: Button
    private lateinit var btnListarTodo:Button
    private lateinit var lstTipoCancCli: ListView

    private var dialogo: AlertDialog.Builder?=null

    private val objtipocancha_Cli=Cliente()


    private var estem = false

    private var tipoCanchaServiceCliente: ClienteService?=null

    private var registrotipocanchaCliente:List<Cliente>?=null

    private val objutilidad= Util()

    var ft: FragmentTransaction?=null


    private var _binding:FragmentoBuscarCliente?=null

    private val binding get() = _binding!!

    @SuppressLint("SetTextI18n")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val raiz= inflater.inflate(R.layout.fragment_fragmento_buscar_cliente, container, false)
        txtBuscarCli = raiz.findViewById(R.id.txtBusCli) //nombre
        btnBuscarCli=raiz.findViewById(R.id.btnSelCli)
        btnListarTodo=raiz.findViewById(R.id.btnListarTodoCliente)
        val txtBuscarCli = raiz.findViewById<SearchView>(R.id.txtBusCli)
        txtBuscarCli.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    buscarClientesPorNombre(query)
                    txtBuscarCli.clearFocus()
                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })

        lstTipoCancCli =raiz.findViewById(R.id.lstCli)


        tipoCanchaServiceCliente = ApiUtil.tipoCanchaService_Cliente
        MostrarTipoCanchaCliente(raiz.context)

        btnBuscarCli.setOnClickListener {
            val name = txtBuscarCli.query.toString()

            if (name.isNotEmpty()) {
                buscarClientesPorNombre(name)

            } else {
                Toast.makeText(context, "Ingrese un nombre para buscar", Toast.LENGTH_SHORT).show()
            }
        }
        // Agregar el botón para mostrar todos los clientes
        btnListarTodo.setOnClickListener {
            mostrarTodosLosClientes()
        }
        return raiz
    }

    private fun buscarClientesPorNombre(nombre: String) {
        val call = tipoCanchaServiceCliente!!.buscarPorNombre(nombre)
        call!!.enqueue(object : Callback<List<Cliente>> {
            override fun onResponse(call: Call<List<Cliente>>, response: Response<List<Cliente>>) {
                val clientes = response.body()
                lstTipoCancCli.adapter = context?.let { AdaptadorBuscarCliente(it, clientes) }
            }

            override fun onFailure(call: Call<List<Cliente>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }
    fun MostrarTipoCanchaCliente(context: Context?) {
        val call=tipoCanchaServiceCliente!!.MostrarTipoCanchaPersonalidaza_Cliente()
        call!!.enqueue(object: Callback<List<Cliente>> {
            override fun onResponse(call: Call<List<Cliente>>, response: Response<List<Cliente>>) {
                if (response.isSuccessful){
                    registrotipocanchaCliente=response.body()
                    lstTipoCancCli.adapter= AdaptadorCliente(context, registrotipocanchaCliente)
                }
            }

            override fun onFailure(call: Call<List<Cliente>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }
    //creamos una funcion para los cuadros del dialogo del CRUD
    fun DialogoCRUD(titulo: String, mensaje: String,fragmento:Fragment){
        dialogo= AlertDialog.Builder(context)
        dialogo!!.setTitle(titulo)
        dialogo!!.setMessage(mensaje)
        dialogo!!.setCancelable(false)
        dialogo!!.setPositiveButton("Ok"){
                dialogo,which->
            ft=fragmentManager?.beginTransaction()
            ft?.replace(R.id.contenedor,fragmento,null)
            ft?.addToBackStack(null)
            ft?.commit()
        }
        dialogo!!.show()
    }
    private fun mostrarTodosLosClientes() {
        val call = tipoCanchaServiceCliente!!.MostrarTipoCanchaPersonalidaza_Cliente()
        call!!.enqueue(object : Callback<List<Cliente>> {
            override fun onResponse(call: Call<List<Cliente>>, response: Response<List<Cliente>>) {
                val clientes = response.body()
                lstTipoCancCli.adapter = context?.let { AdaptadorBuscarCliente(it, clientes) }

            }

            override fun onFailure(call: Call<List<Cliente>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


    }

    override fun onDestroyView() {
        super.onDestroyView()

    }
}