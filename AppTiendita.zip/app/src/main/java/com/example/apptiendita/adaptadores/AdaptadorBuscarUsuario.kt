package com.example.apptiendita.adaptadores

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.apptiendita.R
import com.example.apptiendita.clases.Usuario
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto

class AdaptadorBuscarUsuario   (context: Context, private val Usuario: List<Usuario>?) : BaseAdapter()
{
    private val inflater: LayoutInflater = LayoutInflater.from(context)

    override fun getCount(): Int {
        return Usuario?.size ?: 0
    }

    override fun getItem(position: Int): Any? {
        return Usuario?.get(position)
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var vista = p1
        var viewHolder: ViewHolder

        if (vista == null) {
            vista = inflater.inflate(R.layout.elemento_lista_usuario, p2, false)
            viewHolder = ViewHolder(vista)
            vista.tag = viewHolder
        } else {
            viewHolder = vista.tag as ViewHolder
        }

        val objtipocancha = getItem(p0) as Usuario

        viewHolder.lstCodUsuario.text = ""+objtipocancha.id_cuenta
        viewHolder.lstEmailUsuario.text = ""+objtipocancha.username
        viewHolder.lstPassUsuario.text = ""+objtipocancha.password

        if (objtipocancha.activo) {
            viewHolder.lstEstUsuario.text = "Habilitado"
        } else {
            viewHolder.lstEstUsuario.text = "Deshabilitado"
        }

        return vista!!
    }

    private class ViewHolder(vista: View) {
        val lstCodUsuario=vista!!.findViewById<TextView>(R.id.lstCodUsuario)
        val lstEmailUsuario=vista!!.findViewById<TextView>(R.id.lstEmailUsuario)
        val lstPassUsuario=vista!!.findViewById<TextView>(R.id.lstPassUsuario)
        val lstEstUsuario=vista!!.findViewById<TextView>(R.id.lstEstUsuario)

    }



}