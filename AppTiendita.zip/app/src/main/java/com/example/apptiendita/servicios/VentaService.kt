package com.example.apptiendita.servicios

import com.example.apptiendita.clases.Usuario
import com.example.apptiendita.clases.Venta
import retrofit2.Call
import retrofit2.http.*

interface VentaService {
    @GET("Venta/custom")
    fun MostrarTipoCanchaPersonalidaza_Venta(): Call<List<Venta>>

    @POST("Venta")
    fun RegistrarTipoCancha_Venta(@Body dt: Venta?): Call<List<Venta>>

    @PUT("Venta/{id}")
    fun ActualizarTipoCancha_Venta(@Path("id") idventa: Int, @Body dt: Venta?): Call<List<Venta>>

    @DELETE("Venta/{id}")
    fun EliminarTipoCancha_Venta(@Path("id") idventa: Int): Call<List<Venta>>

    @GET("Venta")
    fun buscarPorNombre(@Query("fecha") fecha: String): Call<List<Venta>>


}