package com.example.apptiendita.adaptadores

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.apptiendita.R
import com.example.apptiendita.clases.DetalleVenta
import com.example.apptiendita.clases.Empleado
import com.example.apptiendita.clases.Venta

class AdaptadorBuscarDetalleVenta (context: Context, private val Venta: List<DetalleVenta>?) : BaseAdapter()
{
    private val inflater: LayoutInflater = LayoutInflater.from(context)


    override fun getCount(): Int {
        return Venta?.size ?: 0
    }

    override fun getItem(position: Int): Any? {
        return Venta?.get(position)
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var vista = p1
        var viewHolder: AdaptadorBuscarDetalleVenta.ViewHolder

        if (vista == null) {
            vista = inflater.inflate(R.layout.elemento_lista_detalle_venta, p2, false)
            viewHolder = AdaptadorBuscarDetalleVenta.ViewHolder(vista)
            vista.tag = viewHolder
        } else {
            viewHolder = vista.tag as AdaptadorBuscarDetalleVenta.ViewHolder
        }

        val objtipocancha_Detalle = getItem(p0) as DetalleVenta

        viewHolder.etid.text = ""+objtipocancha_Detalle.iddetallev
        viewHolder.edtfecha.text=""+ objtipocancha_Detalle.Venta!!.fecha
        viewHolder.edtnompro.text=""+ objtipocancha_Detalle.Producto!!.nombre

        viewHolder.edtCantidad.text = ""+objtipocancha_Detalle.cantidad
        viewHolder.edtprecio.text=""+ objtipocancha_Detalle.precioventa

        if (objtipocancha_Detalle.estado) {
            viewHolder.etest.text = "Habilitado"
        } else {
            viewHolder.etest.text = "Deshabilitado"
        }

        return vista!!
    }


    private class ViewHolder(vista: View) {

        val etid = vista!!.findViewById<TextView>(R.id.edIDetalleVenta)
        val edtnompro = vista!!.findViewById<TextView>(R.id.edtNombrProductoDetalle)
        val edtfecha =vista!!.findViewById<TextView>(R.id.edtFechaVentaListaDetalle)
        val edtCantidad = vista!!.findViewById<TextView>(R.id.edtCantidadDetalle)
        val edtprecio = vista!!.findViewById<TextView>(R.id.edtPrecioVentaDetalle)
        val etest = vista!!.findViewById<TextView>(R.id.etestDetalleVenta)


    }

}