package com.example.apptiendita.adaptadores
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.apptiendita.R
import com.example.apptiendita.clases.Empleado
import com.example.proyecto_movil_crud_mysql_23_52.Clases.*

class AdaptadorEmpleado  (context: Context?, private val listatipocancha_Em:List<Empleado>?):BaseAdapter()
{
    private val layoutInflater: LayoutInflater

    init {
        layoutInflater= LayoutInflater.from(context)
    }

    override fun getCount(): Int {
        return listatipocancha_Em!!.size
    }

    override fun getItem(p0: Int): Any {
        return listatipocancha_Em!![p0]
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var vista = p1
        if (vista == null){

            vista=layoutInflater.inflate(R.layout.elemento_lista_empleado, p2, false)
            val objtipocancha_Em = getItem(p0) as Empleado

            val etid = vista!!.findViewById<TextView>(R.id.etidem)
            val edtnom = vista!!.findViewById<TextView>(R.id.edtNombreEm)
            val edtApe= vista!!.findViewById<TextView>(R.id.edtDireccEm)
            val edtdec= vista!!.findViewById<TextView>(R.id.edtApeEm)
            val edttelef = vista!!.findViewById<TextView>(R.id.edtTelefEm)
            val etest = vista!!.findViewById<TextView>(R.id.etestEm)
            val lstRolUsuario=vista!!.findViewById<TextView>(R.id.lstRolUsuario)

            etid.text = ""+objtipocancha_Em.idtrab
            edtApe.text = ""+objtipocancha_Em.apetrab
            edtnom.text = ""+objtipocancha_Em.nomtrab
            edtdec.text = ""+objtipocancha_Em.directrab
            edttelef.text = ""+objtipocancha_Em.teftrab
            lstRolUsuario.text = objtipocancha_Em.rol?.nombre ?: ""

            if (objtipocancha_Em.estado==true){
                etest.text="Habilitado"
            }else{
                etest.text="Deshabilitado"
            }
        }
        return vista!!
    }

}
