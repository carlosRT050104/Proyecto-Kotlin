package com.example.apptiendita.adaptadores

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.apptiendita.R
import com.example.apptiendita.clases.Usuario


class AdaptadorUsuario(context: Context?, private val listaUsuario:List<Usuario>?): BaseAdapter() {
    private val layoutInflater: LayoutInflater
    init{
        layoutInflater= LayoutInflater.from(context)
    }
    override fun getCount(): Int {
        return listaUsuario!!.size
    }

    override fun getItem(p0: Int): Any {
        return listaUsuario!![p0]
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var vista=p1
        if(vista==null){
            vista=layoutInflater.inflate(R.layout.elemento_lista_usuario,p2,false)
            val objusuario=getItem(p0) as Usuario
            // creamos los controles
            val lstCodUsuario=vista!!.findViewById<TextView>(R.id.lstCodUsuario)
            val lstEmailUsuario=vista!!.findViewById<TextView>(R.id.lstEmailUsuario)
            val lstPassUsuario=vista!!.findViewById<TextView>(R.id.lstPassUsuario)
            val lstEstUsuario=vista!!.findViewById<TextView>(R.id.lstEstUsuario)
            //agregamos valores a los controles
            lstCodUsuario.text=""+objusuario.id_cuenta
            lstEmailUsuario.text=""+objusuario.username
            lstPassUsuario.text=""+objusuario.password
            if(objusuario.activo==true){
                lstEstUsuario.text="Habilitado"
            }else{
                lstEstUsuario.text="Desabilitado"
            }
        }
        return vista!!
    }
}