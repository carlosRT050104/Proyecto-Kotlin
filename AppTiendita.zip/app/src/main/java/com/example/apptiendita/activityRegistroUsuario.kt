package com.example.apptiendita

import android.annotation.SuppressLint
import android.os.Bundle
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.airbnb.lottie.utils.Utils
import com.example.apptiendita.adaptadores.AdaptadorCliente
import com.example.apptiendita.adaptadores.AdaptadorEmpleado
import com.example.apptiendita.clases.Cliente
import com.example.apptiendita.clases.Empleado
import com.example.apptiendita.clases.Usuario
import com.example.apptiendita.remoto.ApiUtil
import com.example.apptiendita.servicios.ClienteService
import com.example.apptiendita.servicios.UsuarioService
import com.example.apptiendita.utilidad.Util
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class activityRegistroUsuario : AppCompatActivity() {
    //declaramos los controles
    private lateinit var txtEmailUsu: EditText
    private lateinit var txtPassUsu: EditText

    private lateinit var chkEstUsu: CheckBox
    private lateinit var btnRegistrarUsu: Button
    private lateinit var btnLogin: Button



    //creamo un objeto de la clase categiroa
    private val objusuario= Usuario()

    //declaramos variables
    private var cod = 0
    private var nom=""
    private var ape=""
    private var email=""
    private var pass=""
    private var dni=""
    private var telf=""
    private var codrol=0
    private var nomrol=""


    private var est=false
    private var fila=-1
    private var indice=-1
    private var pos=-1

    var ft: FragmentTransaction?=null
    private var dialogo: AlertDialog.Builder?=null


    //declaramos el servicio
    private var usuarioService: UsuarioService?=null

    //creamos un arraylist de categoria
    private var registroUsuario:List<Usuario>?=null

    //creamos un objeto de la clase utilidad
    var objutilidad= Util()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro_usuario)
        supportActionBar?.hide()

        //creamos los controles
        txtEmailUsu=findViewById(R.id.txtEmailUsuarioNew)
        txtPassUsu=findViewById(R.id.txtPasswordUsuarioNew)
        chkEstUsu=findViewById(R.id.chkUsuarioNew)
        btnRegistrarUsu=findViewById(R.id.btnRegistrarUsuarioNew)
        btnLogin=findViewById(R.id.btnRegresarLogin)

        //creamos el arraylist de categoria
        registroUsuario=ArrayList()

        //implementamos el servicio
        usuarioService= ApiUtil.usuarioService

        //cargamos el combo categoria

        btnRegistrarUsu.setOnClickListener{
            if(txtEmailUsu.text.toString()==""){
                objutilidad.MensajeToast(this,"Ingresa el Username")
                txtEmailUsu.requestFocus()
            }else if(txtPassUsu.text.toString()==""){
                objutilidad.MensajeToast(this,"Ingrese la contraseña")
                txtPassUsu.requestFocus()
            }else{
                //capturando valores
                email=txtEmailUsu.text.toString()
                pass=txtPassUsu.text.toString()
                est=if(chkEstUsu.isChecked){
                    true
                }else{
                    false
                }

                //enviamos los valores a la clase
                objusuario.username=email
                objusuario.password=pass

                objusuario.activo=est

                //llamamos a la funcion para registrar
                RegistrarUsuario(this,objusuario)
                val fusuario=activityRegistroUsuario()
                Toast.makeText(this, "El usuario se registró correctamente.", Toast.LENGTH_SHORT).show();
            }
        }
        btnLogin.setOnClickListener {
            val intent = Intent(this, ActividadIngreso::class.java)
            startActivity(intent)
        }
    }
    //creamos una funcion para crear producto
    fun RegistrarUsuario(context: Context?,u: Usuario?){
        val call= usuarioService!!.RegistrarUsuario(u)
        call!!.enqueue(object :Callback<Usuario?>{
            override fun onResponse(call: Call<Usuario?>, response: Response<Usuario?>) {
                if(response.isSuccessful){
                    objutilidad.MensajeToast(context!!,"se registro el usuario")
                }
            }

            override fun onFailure(call: Call<Usuario?>, t: Throwable) {
                Log.e("Error: ",t.message!!)
            }


        })
    }


}