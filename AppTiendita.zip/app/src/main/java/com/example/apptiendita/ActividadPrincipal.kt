package com.example.apptiendita

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.widget.Toolbar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import com.example.apptiendita.databinding.ActividadPrincipalBinding
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.snackbar.Snackbar

class ActividadPrincipal : AppCompatActivity() {



    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActividadPrincipalBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        binding = ActividadPrincipalBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val navController = findNavController(R.id.contenedor)
        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)

        binding.toolbar.title = ""
        binding.toolbar.setTitleTextColor(ContextCompat.getColor(this, android.R.color.black))
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id=item.itemId
        return when (id) {
            R.id.jmiInicio ->{
                val finicio = FragmentoInicio()
                supportFragmentManager.beginTransaction().replace(R.id.contenedor,finicio).commit()
                true
            }
            R.id.jmiRol ->{
                val frol = FragmentoRol()
                supportFragmentManager.beginTransaction().replace(R.id.contenedor,frol).commit()
                true
            }
            R.id.jmiUsuario ->{
                val fusuario = FragmentoUsuario()
                supportFragmentManager.beginTransaction().replace(R.id.contenedor,fusuario).commit()
                true
            }
            R.id.jmiProducto ->{
                val fproducto = FragmentoProducto()
                supportFragmentManager.beginTransaction().replace(R.id.contenedor,fproducto).commit()
                true
            }
            R.id.jmiEmpleado ->{
                val fempleado = Fragmento_Empleado()
                supportFragmentManager.beginTransaction().replace(R.id.contenedor,fempleado).commit()
                true
            }
            R.id.jmiCliente ->{
                val fcliente = Fragmento_Cliente()
                supportFragmentManager.beginTransaction().replace(R.id.contenedor,fcliente).commit()
                true
            }
            R.id.jmiVenta ->{
                val fventa = Fragmento_Venta()
                supportFragmentManager.beginTransaction().replace(R.id.contenedor,fventa).commit()
                true
            }
            R.id.jmiBuscarCliente ->{
                val fbuscarcliente=FragmentoBuscarCliente()
                supportFragmentManager.beginTransaction().replace(R.id.contenedor,fbuscarcliente).commit()
                true
            }
            R.id.jmiBuscarEmpleado ->{
                val frmEmpleadoBuscar=FragmentoBuscarEmpleado()
                supportFragmentManager.beginTransaction().replace(R.id.contenedor,frmEmpleadoBuscar).commit()
                true
            }

            R.id.jmiBuscarProducto ->{
                val frmBuscarPro=FragmentoBuscarProducto()
                supportFragmentManager.beginTransaction().replace(R.id.contenedor,frmBuscarPro).commit()
                true
            }
            R.id.jmiBuscarCargo ->{
                val frmRolbuscar=FragmentoBuscarRol()
                supportFragmentManager.beginTransaction().replace(R.id.contenedor,frmRolbuscar).commit()
                true
            }
            R.id.jmiBuscarCuenta ->{
                val frmUsuarioBuscar=FragmentoBuscarUsuario()
                supportFragmentManager.beginTransaction().replace(R.id.contenedor,frmUsuarioBuscar).commit()
                true
            }
            R.id.jmiVentaBuscar ->{
                val frmBuscarVenta=FragmentoBuscarVenta()
                supportFragmentManager.beginTransaction().replace(R.id.contenedor,frmBuscarVenta).commit()
                true
            }
            R.id.jmiBuscarDetalleVenta ->{
                val frmBuscarDetalle=FragmentoBuscarDetalleVenta()
                supportFragmentManager.beginTransaction().replace(R.id.contenedor,frmBuscarDetalle).commit()
                true
            }
            R.id.jmiDetalleVenta ->{
                val fdetalle = Fragmento_Detalle_Venta()
                supportFragmentManager.beginTransaction().replace(R.id.contenedor,fdetalle).commit()
                true
            }
            R.id.jmiCerrar ->{
                val formulario= Intent(this,ActividadIngreso::class.java)
                startActivity(formulario)
                this.finish()
                true
            }
            R.id.jmiSalir ->{
                finish()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.contenedor)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }

}