package com.example.apptiendita

import android.annotation.SuppressLint
import android.os.Bundle
import android.app.AlertDialog
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.example.apptiendita.adaptadores.AdaptadorCliente
import com.example.apptiendita.adaptadores.AdaptadorEmpleado
import com.example.apptiendita.clases.Cliente
import com.example.apptiendita.clases.Empleado
import com.example.apptiendita.remoto.ApiUtil
import com.example.apptiendita.servicios.ClienteService
import com.example.apptiendita.utilidad.Util
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class Fragmento_Cliente : Fragment() {
    private lateinit var txtnombreCli: EditText
    private lateinit var txtApeCli: EditText
    private lateinit var txtTelefCli: EditText
    private lateinit var txtDNIfCli: EditText
    private lateinit var txtDirCli: EditText

    private lateinit var chkEstCli: CheckBox
    private lateinit var codCliente: TextView

    private lateinit var btnRegistrarCli: Button
    private lateinit var btnActualizarCli: Button
    private lateinit var btnEliminarCli: Button
    private lateinit var lstTipoCancCli: ListView

    private var dialogo: AlertDialog.Builder?=null

    private val objtipocancha_Cli=Cliente()

    private var cod = 0
    private var fila =-1

    private var nomcli=""
    private var apecli=""
    private var telefcli=""
    private var dnicli=""
    private var dircli=""

    private var estem = false

    private var tipoCanchaServiceCliente: ClienteService?=null

    private var registrotipocanchaCliente:List<Cliente>?=null

    private val objutilidad= Util()

    var ft: FragmentTransaction?=null


    private var _binding:Fragmento_Cliente?=null

    private val binding get() = _binding!!


    @SuppressLint("SetTextI18n")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val raiz= inflater.inflate(R.layout.activity_fragmento_cliente, container, false)
        txtnombreCli = raiz.findViewById(R.id.txtnombreCli) //nombre
        txtApeCli = raiz.findViewById(R.id.txtApellidoCli)//apellido
        txtTelefCli = raiz.findViewById(R.id.txtTelefCli)//telefono
        txtDNIfCli = raiz.findViewById(R.id.txtDniClie)//dni
        txtDirCli = raiz.findViewById(R.id.txtDireccionCli)///direccion
        chkEstCli = raiz.findViewById(R.id.chkEstCli)//estado
        codCliente = raiz.findViewById(R.id.codCliente)

        btnRegistrarCli = raiz.findViewById(R.id.btnRegistrarCli)
        btnActualizarCli = raiz.findViewById(R.id.btnActualizarCli)
        btnEliminarCli = raiz.findViewById(R.id.btnEliminarcli)
        lstTipoCancCli =raiz.findViewById(R.id.lstTipoCancCli)


        registrotipocanchaCliente=ArrayList()
        tipoCanchaServiceCliente = ApiUtil.tipoCanchaService_Cliente
        MostrarTipoCanchaCliente(raiz.context)


        btnRegistrarCli.setOnClickListener {
            if (txtnombreCli.getText().toString()==""){
                objutilidad.MensajeToast(context, "Ingrese nombre del Cliente")
                txtnombreCli.requestFocus()
            }else if(txtApeCli.getText().toString()==""){
                objutilidad.MensajeToast(context, "Ingrese Apellido del Cliente")
                txtApeCli.requestFocus()

            }else if(txtTelefCli.getText().toString()==""){
                objutilidad.MensajeToast(context, "Ingrese Telefono del Cliente")
                txtTelefCli.requestFocus()

            }else if(txtDNIfCli.getText().toString()==""){
                objutilidad.MensajeToast(context, "Ingrese Dni del Cliente")
                txtDNIfCli.requestFocus()
            }else if(txtDirCli.getText().toString()==""){
                objutilidad.MensajeToast(context, "Ingrese Direccion del Cliente")
                txtDirCli.requestFocus()

            }else{
                nomcli=txtnombreCli.getText().toString()
                apecli=txtApeCli.getText().toString()
                telefcli=txtTelefCli.getText().toString()
                dnicli=txtDNIfCli.getText().toString()
                dircli=txtDirCli.getText().toString()
                estem=if(chkEstCli.isChecked){
                    true
                }else{
                    false
                }
                objtipocancha_Cli.nomcli = nomcli
                objtipocancha_Cli.apecli = apecli
                objtipocancha_Cli.tefcli= telefcli
                objtipocancha_Cli.dni = dnicli
                objtipocancha_Cli.direccion = dircli
                objtipocancha_Cli.estado = estem

                RegistrarTipoCanchaCliente(context, objtipocancha_Cli)

                objutilidad.Limpiar(raiz.findViewById<View>(R.id.frmTipoCanchaCli) as ViewGroup)

                val ftipocancha = Fragmento_Cliente()
                DialogoCRUD(raiz.context,ftipocancha,"Registro de Cliente","Se Registro el Cliente correctamente")

            }
        }
        txtnombreCli = raiz.findViewById(R.id.txtnombreCli) //nombre
        txtApeCli = raiz.findViewById(R.id.txtApellidoCli)//apellido
        txtTelefCli = raiz.findViewById(R.id.txtTelefCli)//telefono
        txtDNIfCli = raiz.findViewById(R.id.txtDniClie)//dni
        txtDirCli = raiz.findViewById(R.id.txtDireccionCli)///direccion
        chkEstCli = raiz.findViewById(R.id.chkEstCli)//estado

        codCliente = raiz.findViewById(R.id.codCliente)//codigo para actualizar eliminar
        lstTipoCancCli =raiz.findViewById(R.id.lstTipoCancCli) //listado

        lstTipoCancCli.setOnItemClickListener(AdapterView.OnItemClickListener
        { parent, view, position, idcliente ->
            fila = position
            codCliente.setText(""+(registrotipocanchaCliente as ArrayList<Cliente>).get(fila).idcliente)
            txtnombreCli.setText(""+(registrotipocanchaCliente as ArrayList<Cliente>).get(fila).nomcli)
            txtApeCli.setText(""+(registrotipocanchaCliente as ArrayList<Cliente>).get(fila).apecli)
            txtTelefCli.setText(""+(registrotipocanchaCliente as ArrayList<Cliente>).get(fila).tefcli)
            txtDNIfCli.setText(""+(registrotipocanchaCliente as ArrayList<Cliente>).get(fila).dni)
            txtDirCli.setText(""+(registrotipocanchaCliente as ArrayList<Cliente>).get(fila).direccion)

            if((registrotipocanchaCliente as ArrayList<Cliente>).get(fila).estado){
                chkEstCli.setChecked(true)
            }else{
                chkEstCli.setChecked(false)
            }
        })

        btnActualizarCli.setOnClickListener {
            if (fila>=0){
                cod = codCliente.getText().toString().toInt()
                nomcli=txtnombreCli.getText().toString()
                apecli=txtApeCli.getText().toString()
                telefcli=txtTelefCli.getText().toString()
                dnicli=txtDNIfCli.getText().toString()
                dircli=txtDirCli.getText().toString()
                estem=if(chkEstCli.isChecked){
                    true
                }else{
                    false
                }
            }
            objtipocancha_Cli.nomcli = nomcli
            objtipocancha_Cli.apecli = apecli
            objtipocancha_Cli.tefcli= telefcli
            objtipocancha_Cli.dni = dnicli
            objtipocancha_Cli.direccion = dircli
            objtipocancha_Cli.estado = estem

            ActualizarTipoCanchaCliente(context, objtipocancha_Cli, cod)

            objutilidad.Limpiar(raiz.findViewById<View>(R.id.frmTipoCanchaCli) as ViewGroup)

            val ftipocancha = Fragmento_Cliente()
            DialogoCRUD(raiz.context,ftipocancha,"Actualizar de Cliente","Se Actualizo el Cliente correctamente")

        }

        btnEliminarCli.setOnClickListener {

            if (fila >= 0){

                cod = codCliente.getText().toString().toInt()

                objtipocancha_Cli.idcliente = cod

                EliminarTipoCanchaCliente(context, cod)

                objutilidad.Limpiar(raiz.findViewById<View>(R.id.frmTipoCanchaCli) as ViewGroup)

                val ftipocancha = Fragmento_Cliente()
                DialogoCRUD(raiz.context,ftipocancha,"Eliminar  Cliente","Se Eliminino  el Cliente correctamente")

            }
        }
        return raiz
    }
    fun MostrarTipoCanchaCliente(context: Context?) {
        val call=tipoCanchaServiceCliente!!.MostrarTipoCanchaPersonalidaza_Cliente()
        call!!.enqueue(object: Callback<List<Cliente>> {
            override fun onResponse(call: Call<List<Cliente>>, response: Response<List<Cliente>>) {
                if (response.isSuccessful){
                    registrotipocanchaCliente=response.body()
                    lstTipoCancCli.adapter= AdaptadorCliente(context, registrotipocanchaCliente)
                }
            }

            override fun onFailure(call: Call<List<Cliente>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }

    fun RegistrarTipoCanchaCliente(context: Context?, tcxd:Cliente?) {
        val call=tipoCanchaServiceCliente!!.RegistrarTipoCancha_Cliente(tcxd)
    call!!.enqueue(object : Callback<List<Cliente>> {
        override fun onResponse(
            call: Call<List<Cliente>>,
            response: Response<List<Cliente>>
        ) {
            if (response.isSuccessful){
                Log.e("mensaje", "Se registro el Cliente")

            }
        }

        override fun onFailure(call: Call<List<Cliente>>, t: Throwable) {
            Log.e("Error", t.message!!)
        }
    })
}
    fun ActualizarTipoCanchaCliente(context: Context?, tcxd:Cliente?, idcliente:Int) {

        val call=tipoCanchaServiceCliente!!.ActualizarTipoCancha_Cliente(idcliente, tcxd)
        call!!.enqueue(object : Callback<List<Cliente>> {
            override fun onResponse(
                call: Call<List<Cliente>>,
                response: Response<List<Cliente>>
            ) {
                if (response.isSuccessful){
                    Log.e("mensaje", "Se actualizo el Cliente")

                }
            }

            override fun onFailure(call: Call<List<Cliente>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }

    fun EliminarTipoCanchaCliente(context: Context?, idcliente:Int) {

        val call=tipoCanchaServiceCliente!!.EliminarTipoCancha_Cliente(idcliente)
        call!!.enqueue(object : Callback<List<Cliente>> {
            override fun onResponse(
                call: Call<List<Cliente>>,
                response: Response<List<Cliente>>
            ) {
                if (response.isSuccessful){
                    Log.e("mensaje", "Se elimino  el Cliente")

                }
            }

            override fun onFailure(call: Call<List<Cliente>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })

    }
    //creamos un procedimiento para Mostrar dialogos de CRUD
    fun DialogoCRUD(context: Context, fproducto:Fragment,titulo:String,mensaje:String){
        dialogo= AlertDialog.Builder(context)
        dialogo!!.setTitle(titulo)
        dialogo!!.setMessage(mensaje)
        dialogo!!.setCancelable(false)
        dialogo!!.setPositiveButton("Ok"){
                dialog,which->
            ft=fragmentManager?.beginTransaction()
            ft?.addToBackStack(null)
            ft?.commit()
        }
        dialogo!!.show()
    }




}


