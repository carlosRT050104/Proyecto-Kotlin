package com.example.apptiendita

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ListView
import android.widget.SearchView
import android.widget.Toast
import androidx.fragment.app.FragmentTransaction
import com.example.apptiendita.adaptadores.*
import com.example.apptiendita.clases.*
import com.example.apptiendita.remoto.ApiUtil
import com.example.apptiendita.servicios.DetalleVentaService
import com.example.apptiendita.utilidad.Util
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response



class FragmentoBuscarDetalleVenta : Fragment() {

    private lateinit var txtBuscarCliDetalle: SearchView
    private lateinit var btnBuscarCliDetalle: Button
    private lateinit var btnListarTodoDetalle: Button
    private lateinit var lstTipoCancCliDetalle: ListView

    private var detalleservice: DetalleVentaService?=null

    private var registrotipocanchPro:List<DetalleVenta>?=null

    private val objutilidad= Util()

    var ft: FragmentTransaction?=null


    private var _binding: FragmentoBuscarDetalleVenta? = null
    private val binding get() = _binding!!

    @SuppressLint("SetTextI18n", "MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val raiz= inflater.inflate(R.layout.fragment_fragmento_buscar_detalle_venta, container, false)
        txtBuscarCliDetalle  = raiz.findViewById(R.id.txtBusClDetalle) //nombre
        btnBuscarCliDetalle =raiz.findViewById(R.id.btnSelCliDetalle)
        btnListarTodoDetalle= raiz.findViewById(R.id.btnListarTodoClienteDetalle)
        lstTipoCancCliDetalle= raiz.findViewById(R.id.lstCliProDetalle)


        txtBuscarCliDetalle.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    val idDetalleVenta = query.toIntOrNull()
                    if (idDetalleVenta != null) {
                        buscarDetalleVentaPorId(idDetalleVenta)
                    } else {
                        Toast.makeText(context, "Ingrese un número válido para buscar", Toast.LENGTH_SHORT).show()
                    }
                    txtBuscarCliDetalle.clearFocus()
                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })
        btnBuscarCliDetalle.setOnClickListener {
            val name = txtBuscarCliDetalle.query.toString()

            if (name.isNotEmpty()) {
                val iddetallev = name.toIntOrNull()
                if (iddetallev != null) {
                    buscarDetalleVentaPorId(iddetallev)
                } else {
                    Toast.makeText(context, "Ingrese un número válido para buscar", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(context, "Ingrese un nombre para buscar", Toast.LENGTH_SHORT).show()
            }
        }


        detalleservice = ApiUtil.tipoCanchaService_DetalleVenta
        mostrarDetalleVenta()

        // Agregar el botón para mostrar todos los clientes
        btnListarTodoDetalle.setOnClickListener {
            mostrarDetalleVenta()
        }

        return raiz
    }

    private fun mostrarDetalleVenta() {
        val call = detalleservice!!.MostrarTipoCanchaPersonalidaza_DetalleVenta()
        call!!.enqueue(object : Callback<List<DetalleVenta>?> {
            override fun onResponse(
                call: Call<List<DetalleVenta>?>,
                response: Response<List<DetalleVenta>?>
            ) {
                if (response.isSuccessful) {
                    registrotipocanchPro = response.body()
                    lstTipoCancCliDetalle.adapter = AdaptadorDetalleVenta(requireContext(), registrotipocanchPro)
                }
            }

            override fun onFailure(call: Call<List<DetalleVenta>?>, t: Throwable) {
                Log.e("Error: ", t.message!!)
            }
        })
    }



    private fun buscarDetalleVentaPorId(iddetallev: Int) {
        val call=detalleservice!!.buscarPorVentaId(iddetallev)
        call!!.enqueue(object: Callback<List<DetalleVenta>> {
            override fun onResponse(call: Call<List<DetalleVenta>>, response: Response<List<DetalleVenta>>) {
                val clientes = response.body()
                lstTipoCancCliDetalle.adapter = context?.let { AdaptadorDetalleVenta(it, clientes) }
            }

            override fun onFailure(call: Call<List<DetalleVenta>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }


}

