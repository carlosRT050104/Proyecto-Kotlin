package com.example.apptiendita

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.FragmentTransaction
import com.example.apptiendita.adaptadores.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.example.apptiendita.clases.*
import com.example.apptiendita.remoto.ApiUtil
import com.example.apptiendita.servicios.*
import com.example.apptiendita.utilidad.Util


class FragmentoUsuario : Fragment() {
    //declaramos los controles
    private lateinit var txtNomUsu: EditText
    private lateinit var txtApeUsu: EditText
    private lateinit var txtEmailUsu: EditText
    private lateinit var txtPassUsu: EditText
    private lateinit var txtDniUsu: EditText
    private lateinit var txtTelfUsu: EditText
    private lateinit var lblCodUsu: TextView

    private lateinit var chkEstUsu: CheckBox
    private lateinit var btnRegistrarUsu: Button
    private lateinit var btnActualizarUsu: Button
    private lateinit var btnEliminarUsu: Button

    private lateinit var cboRol: Spinner
    private lateinit var lstUsu: ListView

    //creamo un objeto de la clase categiroa
    private val objrol= Rol()
    private val objusuario= Usuario()

    //declaramos variables
    private var cod = 0
    private var nom=""
    private var ape=""
    private var email=""
    private var pass=""
    private var dni=""
    private var telf=""
    private var codrol=0
    private var nomrol=""


    private var est=false
    private var fila=-1
    private var indice=-1
    private var pos=-1

    var ft: FragmentTransaction?=null
    private var dialogo: AlertDialog.Builder?=null


    //declaramos el servicio
    private var rolService: RolService?=null
    private var usuarioService: UsuarioService?=null

    //creamos un arraylist de categoria
    private var registroRol:List<Rol>?=null
    private var registroUsuario:List<Usuario>?=null

    //creamos un objeto de la clase utilidad
    var objutilidad= Util()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val raiz=inflater.inflate(R.layout.fragment_fragmento_usuario, container, false)

        //creamos los controles
        lstUsu=raiz.findViewById(R.id.lstUsuario)
        txtEmailUsu=raiz.findViewById(R.id.txtEmailUsuario)
        txtPassUsu=raiz.findViewById(R.id.txtPasswordUsuario)
        lblCodUsu=raiz.findViewById(R.id.lblCodUsuario)
        chkEstUsu=raiz.findViewById(R.id.chkUsuario)
        btnRegistrarUsu=raiz.findViewById(R.id.btnRegistrarUsuario)
        btnActualizarUsu=raiz.findViewById(R.id.btnActualizarUsuario)
        btnEliminarUsu=raiz.findViewById(R.id.btnEliminarUsuario)

        //creamos el arraylist de categoria
        registroRol=ArrayList()
        registroUsuario=ArrayList()

        //implementamos el servicio
        rolService= ApiUtil.rolService
        usuarioService= ApiUtil.usuarioService

        //cargamos el combo categoria
        MostrarUsuario(raiz.context)

        btnRegistrarUsu.setOnClickListener{
            if(txtEmailUsu.text.toString()==""){
                objutilidad.MensajeToast(raiz.context,"Ingresa el Username")
                txtEmailUsu.requestFocus()
            }else if(txtPassUsu.text.toString()==""){
                objutilidad.MensajeToast(raiz.context,"Ingrese la contraseña")
                txtPassUsu.requestFocus()
            }else{
                //capturando valores
                email=txtEmailUsu.text.toString()
                pass=txtPassUsu.text.toString()
                est=if(chkEstUsu.isChecked){
                    true
                }else{
                    false
                }

                //enviamos los valores a la clase
                objusuario.username=email
                objusuario.password=pass



                objusuario.activo=est

                //llamamos a la funcion para registrar
                RegistrarUsuario(raiz.context,objusuario)
                val fusuario=FragmentoUsuario()
                objutilidad.Limpiar(raiz.findViewById<View>(R.id.frmTipoCanchaUsuario) as ViewGroup)
                DialogoCRUD("Registro de usuario", "Se registro el usuario correctamente",fusuario)

            }
        }

        lstUsu.setOnItemClickListener{ adapterView, view, i, l ->
            fila=i
            //asignamos los valores a los controles
            lblCodUsu.setText(""+ (registroUsuario as ArrayList<Usuario>).get(fila).id_cuenta)
            txtEmailUsu.setText(""+ (registroUsuario as ArrayList<Usuario>).get(fila).username)
            txtPassUsu.setText(""+ (registroUsuario as ArrayList<Usuario>).get(fila).password)
            if((registroUsuario as ArrayList<Usuario>).get(fila).activo){
                chkEstUsu.setChecked(true)
            }else{
                chkEstUsu.setChecked(false)
            }
        }

        btnActualizarUsu.setOnClickListener {
            if(fila>=0){
                cod= lblCodUsu.text.toString().toLong().toInt()
                email=txtEmailUsu.text.toString()
                pass=txtPassUsu.text.toString()


                est=if(chkEstUsu.isChecked){
                    true
                }else{
                    false
                }

                //enviamos los valores a la clase

                objusuario.id_cuenta=cod
                objusuario.username=email
                objusuario.password=pass


                objusuario.activo=est




                //llamamos a la funcion para registrar
                ActualizarUsuario(raiz.context,objusuario, cod)
                val fusuario=FragmentoUsuario()
                objutilidad.Limpiar(raiz.findViewById<View>(R.id.frmTipoCanchaUsuario) as ViewGroup)
                DialogoCRUD("Actualizacion de usuario", "Se actualizo el usuario correctamente",fusuario)

            }else{
                objutilidad.MensajeToast(raiz.context,"Seleccione un elemento de la lista")
                lstUsu.requestFocus()
            }
        }

        btnEliminarUsu.setOnClickListener {
            if(fila>=0){
                cod= lblCodUsu.text.toString().toLong().toInt()
                //llamamos a la funcion para registrar
                EliminarUsuario(raiz.context, cod)
                val fusuario=FragmentoUsuario()
                objutilidad.Limpiar(raiz.findViewById<View>(R.id.frmTipoCanchaUsuario) as ViewGroup)
                DialogoCRUD("Eliminacion de usuario", "Se Elimino el usuario correctamente",fusuario)

            }else{
                objutilidad.MensajeToast(raiz.context,"Seleccione un elemento de la lista")
                lstUsu.requestFocus()
            }
        }
        return raiz
    }



    //creamos la funcion para mostrar producto
    fun MostrarUsuario(context: Context?){
        val call= usuarioService!!.MostrarUsuarioPersonalizado()
        call!!.enqueue(object : Callback<List<Usuario>?> {
            override fun onResponse(
                call: Call<List<Usuario>?>,
                response: Response<List<Usuario>?>
            ) {
                if(response.isSuccessful){
                    registroUsuario=response.body()
                    lstUsu.adapter= AdaptadorUsuario(context,registroUsuario)
                }
            }

            override fun onFailure(call: Call<List<Usuario>?>, t: Throwable) {
                Log.e("Error: ",t.message!!)
            }


        })
    }


    //creamos una funcion para crear producto
    fun RegistrarUsuario(context: Context?,u: Usuario?){
        val call= usuarioService!!.RegistrarUsuario(u)
        call!!.enqueue(object :Callback<Usuario?>{
            override fun onResponse(call: Call<Usuario?>, response: Response<Usuario?>) {
                if(response.isSuccessful){
                    objutilidad.MensajeToast(context!!,"se registro el usuario")
                }
            }

            override fun onFailure(call: Call<Usuario?>, t: Throwable) {
                Log.e("Error: ",t.message!!)
            }


        })
    }

    //creamos una funcion para actualizar proveedor
    fun ActualizarUsuario(context: Context?, u: Usuario?, id_cuenta:Int){
        val call= usuarioService!!.ActualizarUsuario(id_cuenta,u)
        call!!.enqueue(object :Callback<Usuario?>{
            override fun onResponse(call: Call<Usuario?>, response: Response<Usuario?>) {
                if(response.isSuccessful){
                    Log.e("mensaje","Se Actualizo correctamente")
                }
            }

            override fun onFailure(call: Call<Usuario?>, t: Throwable) {
                Log.e("Error: ",t.message!!)
            }


        })
    }

    //creamos una funcion para eliminar proveedor
    fun EliminarUsuario(context: Context?, id_cuenta:Int){
        val call= usuarioService!!.EliminarUsuario(id_cuenta)
        call!!.enqueue(object :Callback<Usuario?>{
            override fun onResponse(call: Call<Usuario?>, response: Response<Usuario?>) {
                if(response.isSuccessful){
                    Log.e("mensaje","Se Elimino correctamente")
                }
            }

            override fun onFailure(call: Call<Usuario?>, t: Throwable) {
                Log.e("Error: ",t.message!!)
            }


        })
    }

    //creamos una funcion para los cuadros del dialogo del CRUD
    fun DialogoCRUD(titulo: String, mensaje: String,fragmento:Fragment){
        dialogo= AlertDialog.Builder(context)
        dialogo!!.setTitle(titulo)
        dialogo!!.setMessage(mensaje)
        dialogo!!.setCancelable(false)
        dialogo!!.setPositiveButton("Ok"){
                dialogo,which->
            ft=fragmentManager?.beginTransaction()
            ft?.replace(R.id.contenedor,fragmento,null)
            ft?.addToBackStack(null)
            ft?.commit()
        }
        dialogo!!.show()
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


    }

    override fun onDestroyView() {
        super.onDestroyView()

    }
}