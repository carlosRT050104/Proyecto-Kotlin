package com.example.apptiendita.servicios

import com.example.apptiendita.clases.Empleado
import com.example.apptiendita.clases.Usuario
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*

interface UsuarioService {
    @GET("Cuenta")
    fun MostrarUsuario(): Call<List<Usuario>?>?

    @GET("Cuenta/customer")
    fun MostrarUsuarioPersonalizado(): Call<List<Usuario>?>?

    @POST("Cuenta")
    fun RegistrarUsuario(@Body u: Usuario?): Call<Usuario?>?

    @GET("Cuenta/login/{username}/{password}")
    fun login(@Path("username") username: String, @Path("password") password: String): Call<LoginResponse>

    @PUT("Cuenta/{id}")
    fun ActualizarUsuario(@Path("id") id_cuenta:Int, @Body u: Usuario?): Call<Usuario?>?

    @DELETE("Cuenta/{id}")
    fun EliminarUsuario(@Path("id") id_cuenta:Int): Call<Usuario?>?


    @GET("Cuenta")
    fun buscarPorNombre(@Query("username") username: String): Call<List<Usuario>>

}