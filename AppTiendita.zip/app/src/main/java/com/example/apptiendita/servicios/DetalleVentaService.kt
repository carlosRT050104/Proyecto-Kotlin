package com.example.apptiendita.servicios

import com.example.apptiendita.clases.DetalleVenta
import com.example.apptiendita.clases.Venta
import retrofit2.Call
import retrofit2.http.*

interface DetalleVentaService {
    @GET("DetalleVenta/custom")
    fun MostrarTipoCanchaPersonalidaza_DetalleVenta(): Call<List<DetalleVenta>>

    @POST("DetalleVenta")
    fun RegistrarTipoCancha_DetalleVenta(@Body dt: DetalleVenta?): Call<List<DetalleVenta>>

    @PUT("DetalleVenta/{id}")
    fun ActualizarTipoCancha_DetalleVenta(@Path("id") iddetallev:Int, @Body dt: DetalleVenta?): Call<List<DetalleVenta>>

    @DELETE("DetalleVenta/{id}")
    fun EliminarTipoCancha_DetalleVenta(@Path("id") iddetallev:Int): Call<List<DetalleVenta>>



    @GET("DetalleVenta")
    fun buscarPorVentaId(@Query("iddetallev") iddetallev: Int): Call<List<DetalleVenta>>


}