package com.example.apptiendita.adaptadores
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.apptiendita.R
import com.example.apptiendita.clases.*
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto

class AdaptadorBuscarProducto   (context: Context, private val Producto: List<Producto>?) : BaseAdapter()
{
    private val inflater: LayoutInflater = LayoutInflater.from(context)

    override fun getCount(): Int {
        return Producto?.size ?: 0
    }

    override fun getItem(position: Int): Any? {
        return Producto?.get(position)
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var vista = p1
        var viewHolder: ViewHolder

        if (vista == null) {
            vista = inflater.inflate(R.layout.elemento_lista_producto, p2, false)
            viewHolder = ViewHolder(vista)
            vista.tag = viewHolder
        } else {
            viewHolder = vista.tag as ViewHolder
        }

        val objtipocancha = getItem(p0) as Producto

        viewHolder.etid.text = ""+objtipocancha.productoid
        viewHolder.edtnom.text = ""+objtipocancha.nombre
        viewHolder.edtdec.text = ""+objtipocancha.descripcion
        viewHolder. edtprec.text = ""+objtipocancha.precio

        if (objtipocancha.estado) {
            viewHolder.etest.text = "Habilitado"
        } else {
            viewHolder.etest.text = "Deshabilitado"
        }

        return vista!!
    }

    private class ViewHolder(vista: View) {
        val etid = vista!!.findViewById<TextView>(R.id.etid)
        val edtnom = vista!!.findViewById<TextView>(R.id.edtNombrePro)
        val edtdec= vista!!.findViewById<TextView>(R.id.edtDescrip)
        val edtprec = vista!!.findViewById<TextView>(R.id.edtPrecio)
        val etest = vista!!.findViewById<TextView>(R.id.etest)

    }
}