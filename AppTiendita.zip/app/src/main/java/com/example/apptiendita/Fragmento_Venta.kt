package com.example.apptiendita

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.example.apptiendita.adaptadores.*
import com.example.apptiendita.clases.*
import com.example.apptiendita.remoto.ApiUtil
import com.example.apptiendita.servicios.*
import com.example.apptiendita.utilidad.Util
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Fragmento_Venta : Fragment()  {

    //definiendo controles
    private lateinit var txtfechaVenta: EditText
    private lateinit var cboCat: Spinner
    private lateinit var codVenta: TextView
    private lateinit var chkEstVenta: CheckBox
    private lateinit var lstTipoCancVen: ListView
    private lateinit var btnRegistrarven: Button
    private lateinit var btnActualizarven: Button
    private lateinit var btnEliminarven: Button
    private var dialogo: AlertDialog.Builder?=null

    //creamos un objeto de la clase Categoria
    val objcategoria= Cliente()
    val objproducto= Venta()
    //declaramos el servicio
    private var categoriaService: ClienteService?=null
    private var productoService: VentaService?=null

    //creamos un arraylist de Categoria
    private var registrocategoria:List<Cliente>?=null
    private var registroproducto:List<Venta>?=null
    //creamos un obejto de la clase utilidad
    var objutilidad= Util()

    //declaramos variables
    var cod=0
    var fecha=""
    var est=false
    var fila=-1
    var indice=-1
    var codcat=0L
    var pos=-1
    var nomcat=""
    var selectedPosition = 0 // Por defecto se selecciona la posición 0

    private var ft: FragmentTransaction?=null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val raiz=inflater.inflate(R.layout.activity_fragmento_venta, container, false)

        //creacion de control
        txtfechaVenta=raiz.findViewById(R.id.txtfechaVenta)
        cboCat=raiz.findViewById(R.id.cboCat)
        codVenta=raiz.findViewById(R.id.codVenta)
        lstTipoCancVen=raiz.findViewById(R.id.lstTipoCancVen)
        chkEstVenta=raiz.findViewById(R.id.chkEstVenta)
        btnRegistrarven=raiz.findViewById(R.id.btnRegistrarven)
        btnActualizarven=raiz.findViewById(R.id.btnActualizarven)
        btnEliminarven=raiz.findViewById(R.id.btnEliminarven)


        //creamos el arraylist de Categoria
        registrocategoria=ArrayList()
        registroproducto=ArrayList()

        //implementamos el servicio
        categoriaService= ApiUtil.tipoCanchaService_Cliente
        productoService= ApiUtil.tipoCanchaService_Venta

        //llamamos ala funcion para mostrar los datos del combo
        MostrarComboCategoriaVen(raiz.context)

        //llamamos al metodo para mostrar los producto
        MostrarProductoVen(raiz.context)

        //generamos los eventos
        btnRegistrarven.setOnClickListener {
            if(txtfechaVenta.getText().toString()==""){
                objutilidad.MensajeToast(raiz.context,"Ingrese la fecha")
                txtfechaVenta.requestFocus()
            }else if(cboCat.selectedItemPosition==-1){
                objutilidad.MensajeToast(raiz.context,"Seleccione un Cliente")
                cboCat.requestFocus()
            }else{
                //capturando valores
                fecha=txtfechaVenta.getText().toString()
                pos=cboCat.selectedItemPosition
                codcat= (registrocategoria as ArrayList<Cliente>).get(pos).idcliente.toLong()
                nomcat= (registrocategoria as ArrayList<Cliente>).get(pos).nomcli.toString()
                est=if(chkEstVenta.isChecked){
                    true
                }else{
                    false
                }

                //enviamos los valores a la clase
                objproducto.fecha=fecha

                objcategoria.idcliente= codcat.toInt()
                objproducto.Cliente=objcategoria

                objproducto.estado=est

                RegistrarProductoVen(raiz.context,objproducto)
                val fproducto=FragmentoProducto()
                DialogoCRUD(raiz.context,fproducto,"Registro de Venta","Se registro la Venta correctamente")



            }
        }

        lstTipoCancVen.setOnItemClickListener { parent, view, position, idventa ->
            fila = position
            codVenta.setText((registroproducto as ArrayList<Venta>)[fila].idventa.toString())
            txtfechaVenta.setText((registroproducto as ArrayList<Venta>)[fila].fecha)
            for(i in (registrocategoria as ArrayList<Cliente>).indices){
                if((registrocategoria as ArrayList<Cliente>).get(i).nomcli== (registroproducto as ArrayList<Venta>).get(fila).Cliente?.nomcli){
                    indice=i
                }
            }
            cboCat.setSelection(indice)

            if((registroproducto as ArrayList<Venta>)[fila].estado){
                chkEstVenta.setChecked(true)
            } else{
                chkEstVenta.setChecked(false)
            }
        }
        btnActualizarven.setOnClickListener {
            if(fila>=0){
                cod=Integer.parseInt(codVenta.getText().toString())
                fecha=txtfechaVenta.getText().toString()
                pos=cboCat.selectedItemPosition
                codcat= (registrocategoria as ArrayList<Cliente>).get(pos).idcliente.toLong()
                nomcat= (registrocategoria as ArrayList<Cliente>).get(pos).nomcli.toString()
                est=if(chkEstVenta.isChecked){
                    true
                }else{
                    false
                }

                //enviamos los valores a la clase
                objproducto.idventa= cod.toInt()
                objproducto.fecha=fecha

                objcategoria.idcliente= codcat.toInt()
                objproducto.Cliente=objcategoria

                objproducto.estado=est

                ActualizarTipoCanchaVen(raiz.context,objproducto,cod)
                val fproducto=FragmentoProducto()
                DialogoCRUD(raiz.context,fproducto,"Actualizacion de Venta","Se actualizo la Venta correctamente")

            }else{
                objutilidad.MensajeToast(raiz.context,"Seleccione un elemento de la lista")
                lstTipoCancVen.requestFocus()
            }
        }
        btnEliminarven.setOnClickListener {

            if (fila >= 0){

                cod = codVenta.getText().toString().toInt()

                objproducto.idventa = cod

                EliminarTipoCancha(context, cod)
                val ftipocancha = FragmentoProducto()
                DialogoCRUD(raiz.context,ftipocancha,"Eliminar  Venta","Se Eliminino  el Venta correctamente")
            }
        }

        return raiz
    }

    //crear una funcion para que el combo cargue
    fun MostrarComboCategoriaVen(context: Context?){
        val call= categoriaService!!.MostrarTipoCanchaPersonalidaza_Cliente()
        call!!.enqueue(object : Callback<List<Cliente>?> {
            override fun onResponse(
                call: Call<List<Cliente>?>,
                response: Response<List<Cliente>?>
            ) {
                if(response.isSuccessful){
                    registrocategoria=response.body()
                    cboCat.adapter= AdaptadorComboCli(context,registrocategoria)
                }
            }

            override fun onFailure(call: Call<List<Cliente>?>, t: Throwable) {
                Log.e("Error: ", t.message!!)
            }


        })
    }

    //creamos la funcion para mostrar productos
    fun MostrarProductoVen(context: Context?){
        val call= productoService!!.MostrarTipoCanchaPersonalidaza_Venta()
        call!!.enqueue(object :Callback<List<Venta>?>{
            override fun onResponse(
                call: Call<List<Venta>?>,
                response: Response<List<Venta>?>
            ) {
                if(response.isSuccessful){
                    registroproducto=response.body()
                    lstTipoCancVen.adapter=AdaptadorVenta(context,registroproducto)
                }
            }

            override fun onFailure(call: Call<List<Venta>?>, t: Throwable) {
                Log.e("Error: ", t.message!!)
            }
        })
    }



    fun RegistrarProductoVen(context: Context?, tcxd:Venta?) {
        val call= productoService!!.RegistrarTipoCancha_Venta(tcxd)
        call!!.enqueue(object : Callback<List<Venta>> {
            override fun onResponse(
                call: Call<List<Venta>>,
                response: Response<List<Venta>>
            ) {
                if (response.isSuccessful){
                    Log.e("mensaje", "Se registro el Cliente")

                }
            }

            override fun onFailure(call: Call<List<Venta>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }

    fun ActualizarTipoCanchaVen(context: Context?, tcx:Venta?, idventa: Int) {

        val call=productoService!!.ActualizarTipoCancha_Venta(idventa, tcx)
        call!!.enqueue(object : Callback<List<Venta>> {
            override fun onResponse(
                call: Call<List<Venta>>,
                response: Response<List<Venta>>
            ) {
                if (response.isSuccessful){
                    Log.e("mensaje", "Se actualizo el empleado")

                }
            }

            override fun onFailure(call: Call<List<Venta>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })

    }

    fun EliminarTipoCancha(context: Context?, idventa:Int) {

        val call=productoService!!.EliminarTipoCancha_Venta(idventa)
        call!!.enqueue(object : Callback<List<Venta>> {
            override fun onResponse(
                call: Call<List<Venta>>,
                response: Response<List<Venta>>
            ) {
                if (response.isSuccessful){
                    Log.e("mensaje", "Se elimino la Venta")

                }
            }

            override fun onFailure(call: Call<List<Venta>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        }
        )
    }




    //creamos un procedimiento para Mostrar dialogos de CRUD
    fun DialogoCRUD(context: Context, fproducto:Fragment,titulo:String,mensaje:String){
        dialogo= AlertDialog.Builder(context)
        dialogo!!.setTitle(titulo)
        dialogo!!.setMessage(mensaje)
        dialogo!!.setCancelable(false)
        dialogo!!.setPositiveButton("Ok"){
                dialog,which->
            ft=fragmentManager?.beginTransaction()
            ft?.addToBackStack(null)
            ft?.commit()
        }
        dialogo!!.show()
    }

    
}

private fun <T> Call<T>.enqueue(callback: Callback<Venta?>) {

}

