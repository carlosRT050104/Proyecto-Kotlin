package com.example.apptiendita.remoto

import com.example.apptiendita.servicios.*

object ApiUtil {
    //configuramos una constante con la direccion del servicio
    val API_URL ="http://192.168.18.4:9950/api-cancha/"
    //llamamos ala funcion getCliente del RetrofitCLient
    val tipoCanchaService:ProductoService?
        get()=RetrofitClient.getClient(API_URL)?.create(ProductoService::class.java)

    val tipoCanchaService_Em:EmpleadoService?
        get()=RetrofitClient.getClient(API_URL)?.create(EmpleadoService::class.java)

    val tipoCanchaService_Cliente:ClienteService?
        get()=RetrofitClient.getClient(API_URL)?.create(ClienteService::class.java)

    val tipoCanchaService_Venta:VentaService?
        get()=RetrofitClient.getClient(API_URL)?.create(VentaService::class.java)

    val tipoCanchaService_DetalleVenta:DetalleVentaService?
        get()=RetrofitClient.getClient(API_URL)?.create(DetalleVentaService::class.java)

    val rolService:RolService?
        get()=RetrofitClient.getClient(API_URL)?.create(RolService::class.java)

    val usuarioService:UsuarioService?
        get()=RetrofitClient.getClient(API_URL)?.create(UsuarioService::class.java)
}