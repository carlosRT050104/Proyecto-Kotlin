package com.example.apptiendita

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import androidx.fragment.app.FragmentTransaction
import com.example.apptiendita.adaptadores.AdaptadorRol
import com.example.apptiendita.clases.*
import com.example.apptiendita.remoto.ApiUtil
import com.example.apptiendita.servicios.*
import com.example.apptiendita.utilidad.Util
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class FragmentoRol : Fragment() {
    //declaramos los controles
    private lateinit var txtNom:EditText
    private lateinit var chkRol:CheckBox
    private lateinit var lblCodRol:TextView
    private lateinit var btnRegistrar:Button
    private lateinit var btnActualizar:Button
    private lateinit var btnEliminar:Button
    private lateinit var lstRol:ListView

    //creamos un objeto de la clase Rol
    val objrol= Rol()

    //declaramos variables
    private var cod=0
    private var nom=""
    private var est=false
    private var fila=-1

    //declaramos el servicio
    private var rolService: RolService?=null

    //creamos un arrayList de Rol
    private var registrorol:List<Rol>?=null

    //creamos un objeto de la clase utilidad
    var objutilidad= Util()

    //creamos una transicion para el fragmento
    var ft:FragmentTransaction?=null

    private var dialogo: AlertDialog.Builder?=null

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val raiz=inflater.inflate(R.layout.fragment_fragmento_rol,container,false)
        //creamos los controles
        txtNom=raiz.findViewById(R.id.txtNomRol)
        chkRol=raiz.findViewById(R.id.chkEstRol)
        lblCodRol=raiz.findViewById(R.id.lblCodRol)
        btnRegistrar=raiz.findViewById(R.id.btnRegistrarRol)
        btnActualizar=raiz.findViewById(R.id.btnActualizarRol)
        btnEliminar=raiz.findViewById(R.id.btnEliminarRol)
        lstRol=raiz.findViewById(R.id.lstRol)

        //creamos el arraylis de Rol
        registrorol=ArrayList()

        //implementamos el servicio
        rolService= ApiUtil.rolService

        //mostramos los roles
        MostrarRol(raiz.context)

        //agregamos los eventos
        btnRegistrar.setOnClickListener{
            if(txtNom.getText().toString()==""){
                objutilidad.MensajeToast(raiz.context,"Ingrese el nombre")
                txtNom.requestFocus()
            }else{
                //capturando valores
                nom=txtNom.getText().toString()
                est=if(chkRol.isChecked){
                    true
                }else{
                    false
                }
                //enviamos los valores a la clase
                objrol.nombre=nom
                objrol.activo=est
                //llamamos al metodo para registrar
                RegistrarRol(raiz.context,objrol)
                objutilidad.Limpiar(raiz.findViewById<View>(R.id.frmTipoRol) as ViewGroup)
                //actualizamos el fragmento
                val frol=FragmentoRol()
                DialogoCRUD("Registro de Rol","Se registro el rol", frol)
            }
        }
        lstRol.setOnItemClickListener(AdapterView.OnItemClickListener
        { parent, view, position, id ->
            fila=position
            //asignamos los valores a cada control
            lblCodRol.setText(""+(registrorol as ArrayList<Rol>).get(fila).id_Cargo)
            txtNom.setText(""+(registrorol as ArrayList<Rol>).get(fila).nombre)
            if((registrorol as ArrayList<Rol>).get(fila).activo){
                chkRol.setChecked(true)
            }else{
                chkRol.setChecked(false)

            }
        })


        btnActualizar.setOnClickListener {
            if (fila >= 0) {
                cod = lblCodRol.getText().toString().toInt()
                nom = txtNom.getText().toString()
                est = if (chkRol.isChecked) {
                    true
                } else {
                    false
                }
                objrol.id_Cargo = cod
                objrol.nombre = nom
                objrol.activo = est

                ActualizarRol(context, objrol, cod)

                objutilidad.Limpiar(raiz.findViewById<View>(R.id.frmTipoRol) as ViewGroup)
                val frol = FragmentoRol()
                DialogoCRUD("Actualizacion de Rol", "Se Actualizo el rol", frol)
            } else {
                objutilidad.MensajeToast(raiz.context, "Seleccione un elemento de la lista")
                lstRol.requestFocus()
            }

        }
        btnEliminar.setOnClickListener{
            if (fila >= 0) {
                cod = lblCodRol.getText().toString().toLong().toInt()

                objrol.id_Cargo = cod

                EliminarRol(raiz.context,cod)

                objutilidad.Limpiar(raiz.findViewById<View>(R.id.frmTipoRol) as ViewGroup)
                val frol = FragmentoRol()
                DialogoCRUD("Eliminar  Rol", "Se Elimino el rol", frol)
            } else {
                objutilidad.MensajeToast(raiz.context, "Seleccione un elemento de la lista")
                lstRol.requestFocus()
            }
        }

        return raiz
    }
    //creamos la funcion para mostrar rol
    fun MostrarRol(context: Context?){
        val call=rolService!!.MostrarRolPersonalizado()
        call!!.enqueue(object : Callback<List<Rol>?> {
            override fun onResponse(call: Call<List<Rol>?>, response: Response<List<Rol>?>) {
                if(response.isSuccessful){
                    registrorol=response.body()
                    lstRol.adapter= AdaptadorRol(context,registrorol)
                }
            }

            override fun onFailure(call: Call<List<Rol>?>, t: Throwable) {
                Log.e("Error: ", t.message!!)
            }

        })
    }

    //creamos una funcion para registrar rol
    fun RegistrarRol(context: Context?,r: Rol?){
        val call= rolService!!.RegistrarRol(r)
        call!!.enqueue(object :Callback<Rol?>{
            override fun onResponse(call: Call<Rol?>, response: Response<Rol?>) {
                if(response.isSuccessful){
                    objutilidad.MensajeToast(context!!,"se registro el Rol")
                }
            }

            override fun onFailure(call: Call<Rol?>, t: Throwable) {
                Log.e("Error: ",t.message!!)
            }


        })
    }


    fun ActualizarRol(context: Context?, tcx:Rol?, id_Cargo:Int) {

        val call=rolService!!.ActualizarTipoCancha_ROl(id_Cargo, tcx)
        call!!.enqueue(object : Callback<List<Rol>> {
            override fun onResponse(
                call: Call<List<Rol>>,
                response: Response<List<Rol>>
            ) {
                if (response.isSuccessful){
                    Log.e("mensaje", "Se actualizo el empleado")

                }
            }

            override fun onFailure(call: Call<List<Rol>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })

    }
    //creamos una funcion para eliminar proveedor
    fun EliminarRol(context: Context?, id_Cargo:Int){
        val call= rolService!!.EliminarRol(id_Cargo)
        call!!.enqueue(object :Callback<Rol?>{
            override fun onResponse(call: Call<Rol?>, response: Response<Rol?>) {
                if(response.isSuccessful){
                    Log.e("mensaje","Se Elimino correctamente")
                }
            }

            override fun onFailure(call: Call<Rol?>, t: Throwable) {
                Log.e("Error: ",t.message!!)
            }


        })
    }

    //creamos una funcion para los cuadros del dialogo del CRUD
    fun DialogoCRUD(titulo: String, mensaje: String,fragmento:Fragment){
        dialogo= AlertDialog.Builder(context)
        dialogo!!.setTitle(titulo)
        dialogo!!.setMessage(mensaje)
        dialogo!!.setCancelable(false)
        dialogo!!.setPositiveButton("Ok"){
                dialogo,which->
            ft=fragmentManager?.beginTransaction()
            ft?.replace(R.id.contenedor,fragmento,null)
            ft?.addToBackStack(null)
            ft?.commit()
        }
        dialogo!!.show()
    }

}