package com.example.apptiendita.adaptadores

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.apptiendita.R
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto


class AdaptadorProducto  (context: Context?, private val listatipocancha:List<Producto>?):
    BaseAdapter() {
    private val layoutInflater: LayoutInflater

    init {
        layoutInflater= LayoutInflater.from(context)
    }

    override fun getCount(): Int {
        return listatipocancha!!.size
    }

    override fun getItem(p0: Int): Any {
        return listatipocancha!![p0]
    }

    override fun getItemId(p0: Int): Long {
        return p0.toLong()
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        var vista = p1
        if (vista == null){

            vista=layoutInflater.inflate(R.layout.elemento_lista_producto, p2, false)
            val objtipocancha = getItem(p0) as Producto

            val etid = vista!!.findViewById<TextView>(R.id.etid)
            val edtnom = vista!!.findViewById<TextView>(R.id.edtNombrePro)
            val edtdec= vista!!.findViewById<TextView>(R.id.edtDescrip)
            val edtprec = vista!!.findViewById<TextView>(R.id.edtPrecio)

            val etest = vista!!.findViewById<TextView>(R.id.etest)

            etid.text = ""+objtipocancha.productoid
            edtnom.text = ""+objtipocancha.nombre
            edtdec.text = ""+objtipocancha.descripcion
            edtprec.text = ""+objtipocancha.precio

            if (objtipocancha.estado==true){
                etest.text="Habilitado"
            }else{
                etest.text="Deshabilitado"
            }
        }
        return vista!!
    }
}