package com.example.apptiendita.clases

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Usuario {
    @SerializedName("id_cuenta")
    @Expose
    var id_cuenta: Int = 0


    @SerializedName("username")
    @Expose
    var username:String?=null



    @SerializedName("password")
    @Expose
    var password:String?=null




    @SerializedName("activo")
    @Expose
    var activo:Boolean=false


    constructor(){}
    constructor(id_cuenta: Int, username: String?, password: String?, activo: Boolean) {
        this.id_cuenta = id_cuenta
        this.username = username
        this.password = password
        this.activo = activo
    }


}