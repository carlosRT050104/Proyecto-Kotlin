package com.example.apptiendita.servicios

import com.example.apptiendita.clases.Empleado
import com.example.apptiendita.clases.Rol
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.*

import retrofit2.http.Path

interface RolService {
    @GET("rol")
    fun MostrarRol():Call<List<Rol>?>?

    @GET("rol/custom")
    fun MostrarRolPersonalizado():Call<List<Rol>?>?

    @POST("rol")
    fun RegistrarRol(@Body r: Rol?):Call<Rol?>?

    @PUT("rol/{id}")
    fun ActualizarTipoCancha_ROl(@Path("id") id_Cargo:Int, @Body dt: Rol?): Call<List<Rol>>

    @DELETE("rol/{id}")
    fun EliminarRol(@Path("id") id_Cargo:Int): Call<Rol?>?

    @GET("rol")
    fun buscarPorNombre(@Query("nombre") nombre: String): Call<List<Rol>>
}