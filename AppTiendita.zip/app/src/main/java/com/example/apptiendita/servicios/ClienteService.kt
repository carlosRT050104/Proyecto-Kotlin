package com.example.apptiendita.servicios

import com.example.apptiendita.clases.Cliente
import retrofit2.Call
import retrofit2.http.*

interface ClienteService {
    @GET("Cliente/custom")
    fun MostrarTipoCanchaPersonalidaza_Cliente(): Call<List<Cliente>>

    @GET("Cliente")
    fun buscarPorNombre(@Query("nombre") nombre: String): Call<List<Cliente>>

    @POST("Cliente")
    fun RegistrarTipoCancha_Cliente(@Body dt: Cliente?): Call<List<Cliente>>

    @PUT("Cliente/{id}")
    fun ActualizarTipoCancha_Cliente(@Path("id") idcliente:Int, @Body dt: Cliente?): Call<List<Cliente>>

    @DELETE("Cliente/{id}")
    fun EliminarTipoCancha_Cliente(@Path("id") idcliente:Int): Call<List<Cliente>>


}