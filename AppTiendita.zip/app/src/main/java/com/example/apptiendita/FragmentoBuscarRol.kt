package com.example.apptiendita

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ListView
import android.widget.SearchView
import android.widget.Toast
import androidx.fragment.app.FragmentTransaction
import com.example.apptiendita.adaptadores.AdaptadorBuscarProducto
import com.example.apptiendita.adaptadores.AdaptadorBuscarRol
import com.example.apptiendita.adaptadores.AdaptadorProducto
import com.example.apptiendita.adaptadores.AdaptadorRol
import com.example.apptiendita.clases.Rol
import com.example.apptiendita.remoto.ApiUtil
import com.example.apptiendita.servicios.ProductoService
import com.example.apptiendita.servicios.RolService
import com.example.apptiendita.utilidad.Util
import com.example.proyecto_movil_crud_mysql_23_52.Clases.Producto
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class FragmentoBuscarRol : Fragment() {
    private lateinit var txtBuscarCliRol: SearchView
    private lateinit var btnBuscarCliRol:  Button
    private lateinit var btnListarTodoRol:  Button
    private lateinit var lstTipoCancCliRol:  ListView





    private var tipoCanchaServiceProRol: RolService?=null

    private var registrotipocanchPro:List<Rol>?=null

    private val objutilidad= Util()

    var ft: FragmentTransaction?=null


    private var _binding:FragmentoBuscarRol?=null

    private val binding get() = _binding!!

    @SuppressLint("SetTextI18n")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val raiz= inflater.inflate(R.layout.fragment_fragmento_buscar_rol, container, false)
        txtBuscarCliRol  = raiz.findViewById(R.id.txtBusClRol) //nombre
        btnBuscarCliRol =raiz.findViewById(R.id.btnSelCliRol)
        btnListarTodoRol= raiz.findViewById(R.id.btnListarTodoClienteRol)
        val txtBuscarCliRol = raiz.findViewById<SearchView>(R.id.txtBusClRol)
        txtBuscarCliRol.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    buscarClientesPorNombre(query)
                    txtBuscarCliRol.clearFocus()
                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })

        lstTipoCancCliRol =raiz.findViewById(R.id.lstCliProRol)


        tipoCanchaServiceProRol = ApiUtil.rolService
        MostrarRol(raiz.context)

        btnBuscarCliRol.setOnClickListener {
            val name = txtBuscarCliRol.query.toString()

            if (name.isNotEmpty()) {
                buscarClientesPorNombre(name)

            } else {
                Toast.makeText(context, "Ingrese un nombre para buscar", Toast.LENGTH_SHORT).show()
            }
        }
        // Agregar el botón para mostrar todos los clientes
        btnListarTodoRol.setOnClickListener {
            MostrarRol(raiz.context)
        }
        return raiz
    }

    private fun buscarClientesPorNombre(nombre: String) {
        val call=tipoCanchaServiceProRol!!.buscarPorNombre(nombre)
        call!!.enqueue(object: Callback<List<Rol>> {
            override fun onResponse(call: Call<List<Rol>>, response: Response<List<Rol>>) {
                val clientes = response.body()
                lstTipoCancCliRol.adapter = context?.let { AdaptadorBuscarRol(it, clientes) }
            }

            override fun onFailure(call: Call<List<Rol>>, t: Throwable) {
                Log.e("Error", t.message!!)
            }
        })
    }

    //creamos la funcion para mostrar rol
    fun MostrarRol(context: Context?){
        val call=tipoCanchaServiceProRol!!.MostrarRolPersonalizado()
        call!!.enqueue(object : Callback<List<Rol>?> {
            override fun onResponse(call: Call<List<Rol>?>, response: Response<List<Rol>?>) {
                if(response.isSuccessful){
                    registrotipocanchPro=response.body()
                    lstTipoCancCliRol.adapter= AdaptadorRol(context,registrotipocanchPro)
                }
            }

            override fun onFailure(call: Call<List<Rol>?>, t: Throwable) {
                Log.e("Error: ", t.message!!)
            }

        })
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


    }

    override fun onDestroyView() {
        super.onDestroyView()

    }
}